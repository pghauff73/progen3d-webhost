(function () {
  'use strict';

  const STORAGE_KEY = 'p3d_writer_draft_v1';
  const MAX_ERROR_RETRIES = 10;
  const REGENERATE_DELAY_MS = 10000;
  const resultsEl = document.getElementById('writerResults');
  const seedInput = document.getElementById('writerSeed');
  const countInput = document.getElementById('writerCount');
  const depthInput = document.getElementById('writerDepth');
  const overlapInput = document.getElementById('writerOverlap');
  const generateBtn = document.getElementById('writerGenerateBtn');
  const randomSeedBtn = document.getElementById('writerRandomSeedBtn');
  if (!resultsEl || !seedInput || !countInput || !depthInput || !generateBtn || !randomSeedBtn) return;

  const texturePool = [
    'roughConcrete', 'smoothConcrete', 'redBrickWall', 'whiteTiles', 'blueCeramicTile',
    'shinySteel', 'brushedAluminum', 'oxidizedCopper', 'agedBronze', 'rawIron',
    'clearGlass', 'frostedGlass', 'tintedGreenGlass', 'grayStone', 'darkBasalt',
    'oakPlanks', 'darkWalnut', 'pineWood', 'mahoganyWood', 'carbonFiber',
    'steelGrid', 'chromeSurface', 'glowingPanel', 'greenMarble', 'whiteMarble'
  ];
  const overlapMap = { loose: 0.08, joined: 0.18, fused: 0.30 };
  const overlapLabels = { loose: 'Loose', joined: 'Joined', fused: 'Fused' };
  const familyWeights = {
    foundational: 1.0,
    derived: 0.95,
    architectural: 0.9,
    fractal: 0.6,
    symmetry: 0.55
  };
  const archetypeCatalog = {
    foundational: ['Stack', 'Ring', 'Spokes', 'Band', 'Grid'],
    derived: ['RingStack', 'Spiral', 'Fork', 'RadialGrid', 'Ribbon'],
    architectural: ['TerracedStack', 'FacadeBandGrid', 'VaultedRingGrid', 'RadialCanopy'],
    fractal: ['RecursiveRing'],
    symmetry: ['Dihedral']
  };
  const titleLeads = {
    Stack: ['Tower', 'Column', 'Pagoda', 'Spire'],
    Ring: ['Halo', 'Orbit', 'Collar', 'Wheel'],
    Spokes: ['Canopy', 'Star', 'Petal', 'Ribbed'],
    Band: ['Bridge', 'Span', 'Track', 'Rib'],
    Grid: ['Matrix', 'Field', 'Lattice', 'Array'],
    RingStack: ['Concentric', 'Tiered', 'Cage', 'Amphi'],
    Spiral: ['Helix', 'Spiral', 'Ramp', 'Twist'],
    Fork: ['Forked', 'Branching', 'Arbor', 'Split'],
    RadialGrid: ['Plaza', 'Stadium', 'Solar', 'Polar'],
    Ribbon: ['Ribbon', 'Sweep', 'Skin', 'Stream'],
    TerracedStack: ['Terraced', 'Setback', 'Ziggurat', 'Stepped'],
    FacadeBandGrid: ['Facade', 'Curtain', 'Window', 'Panel'],
    VaultedRingGrid: ['Vaulted', 'Hall', 'Arch', 'Canopy'],
    RadialCanopy: ['Umbrella', 'Canopy', 'Shelter', 'Bloom'],
    RecursiveRing: ['Filigree', 'Recursive', 'Nested', 'Lace'],
    Dihedral: ['Dihedral', 'Paired', 'Bilateral', 'Lobed']
  };
  const titleTails = ['Lantern', 'Pavilion', 'Crown', 'Grove', 'Lattice', 'Bloom', 'Vault', 'Shelter'];

  const draftOrder = [];
  const draftStore = new Map();
  let generationSerial = 0;

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, function (ch) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch] || ch;
    });
  }

  function formatNum(value) {
    return Number(value).toFixed(3).replace(/\.0+$/, '').replace(/(\.\d*?)0+$/, '$1');
  }

  function nextSeed(base, offset) {
    return (((base >>> 0) || 1) + (((offset + 1) * 2654435761) >>> 0)) >>> 0;
  }

  function clearValidationState() {
    if (typeof variable_list !== 'undefined' && Array.isArray(variable_list)) variable_list.length = 0;
    if (typeof full_variable_list !== 'undefined' && Array.isArray(full_variable_list)) full_variable_list.length = 0;
  }

  function countGeneratedCubes(grammar) {
    if (!grammar || !Array.isArray(grammar.tokens_new)) return 0;
    let total = 0;
    for (const tok of grammar.tokens_new) {
      if (!tok || tok.token_name !== 'I') continue;
      if (String(tok.instance_type || '').indexOf('Cube') === 0) {
        total += Math.max(1, Number(tok.instance_count || 1));
      }
    }
    return total;
  }

  function validateGrammarWithParser(grammarText) {
    const trimmed = String(grammarText || '').trim();
    if (!trimmed) return { ok: false, message: 'Empty grammar draft.', cubes: 0 };
    if (typeof Grammar !== 'function') {
      return { ok: false, message: 'Grammar parser is not available on this page.', cubes: 0 };
    }
    try {
      clearValidationState();
      if (typeof RNG !== 'undefined' && RNG && typeof RNG.setSeed === 'function') {
        RNG.setSeed(Date.now() >>> 0);
      }
      const grammar = new Grammar(trimmed);
      return { ok: true, message: 'Parser check passed.', cubes: countGeneratedCubes(grammar) };
    } catch (err) {
      return {
        ok: false,
        message: err && err.message ? err.message : 'Unknown grammar parser error.',
        cubes: 0
      };
    }
  }

  function statusLabel(status) {
    switch (status) {
      case 'valid': return '✓ Error free';
      case 'invalid': return 'Parser error';
      case 'retrying': return 'Retry queued';
      case 'halted': return 'Stopped';
      default: return 'Checking';
    }
  }

  function clearDraftTimers() {
    draftStore.forEach(function (draft) {
      if (draft.retryTimer) {
        clearTimeout(draft.retryTimer);
        draft.retryTimer = null;
      }
    });
  }

  function renderScripts() {
    resultsEl.innerHTML = draftOrder.map(function (id, index) {
      const item = draftStore.get(id);
      if (!item) return '';
      const motifTags = item.motifs.map(function (motif) {
        return '<span class="example-tag">' + escapeHtml(motif) + '</span>';
      }).join('');
      const openDisabled = item.status !== 'valid';
      const cubeSummary = item.status === 'valid' ? ' · cubes ' + escapeHtml(item.cubeCount) : '';
      const errorSummary = item.errorCount > 0 ? ' · parser errors ' + escapeHtml(item.errorCount) + '/' + MAX_ERROR_RETRIES : '';
      const retrySummary = item.status === 'retrying' ? ' · regenerating in 10 seconds' : '';
      return [
        '<article class="writer-card panel">',
        '  <div class="writer-card__head">',
        '    <div>',
        '      <span class="page-kicker">Draft ' + (index + 1) + '</span>',
        '      <h3>' + escapeHtml(item.title) + '</h3>',
        '      <p>Seed ' + escapeHtml(item.seed) + ' · depth ' + escapeHtml(item.depth) + ' · join ' + escapeHtml(item.overlapLabel || 'Joined') + ' · primary ' + escapeHtml(item.primaryArchetype) + ' · secondary ' + escapeHtml(item.secondaryArchetype) + '</p>',
        '    </div>',
        '    <div class="writer-card__actions">',
        '      <button class="btn btn-secondary btn-sm js-copy-writer" type="button" data-copy-label="Copy grammar" data-grammar="' + escapeHtml(item.grammar) + '">Copy grammar</button>',
        '      <a class="btn btn-primary btn-sm js-open-writer' + (openDisabled ? ' is-disabled' : '') + '" href="editor.php"' + (openDisabled ? ' aria-disabled="true" tabindex="-1"' : '') + ' data-title="' + escapeHtml(item.title) + '" data-grammar="' + escapeHtml(item.grammar) + '">Open in editor</a>',
        '    </div>',
        '  </div>',
        '  <div class="writer-card__validation">',
        '    <span class="writer-status writer-status--' + escapeHtml(item.status) + '">' + escapeHtml(statusLabel(item.status)) + '</span>',
        '    <p class="writer-validation-message">' + escapeHtml(item.validationMessage || 'Waiting for parser check...') + '</p>',
        '    <p class="writer-validation-detail">Checks run ' + escapeHtml(item.validationRuns) + cubeSummary + errorSummary + retrySummary + '</p>',
        '  </div>',
        '  <div class="writer-card__meta">' + motifTags + '<span class="example-tag">' + escapeHtml(item.familySignature) + '</span><span class="example-tag">' + escapeHtml(item.textureSet) + '</span></div>',
        '  <pre class="example-code writer-code"><code>' + escapeHtml(item.grammar) + '</code></pre>',
        '</article>'
      ].join('');
    }).join('');
  }

  class OrganicGrammarWriter {
    constructor(seed, options = {}) {
      this.seed = (seed >>> 0) || 1;
      this.initialSeed = this.seed;
      this.options = options;
    }

    rand() {
      let x = this.seed >>> 0;
      x ^= x << 13;
      x ^= x >>> 17;
      x ^= x << 5;
      this.seed = x >>> 0;
      return (this.seed >>> 0) / 4294967296;
    }

    randInt(min, max) {
      return Math.floor(this.rand() * (max - min + 1)) + min;
    }

    randFloat(min, max) {
      return min + (max - min) * this.rand();
    }

    pick(arr) {
      return arr[this.randInt(0, arr.length - 1)];
    }

    weightedPick(items, weightFn) {
      const total = items.reduce((sum, item) => sum + Math.max(0.0001, weightFn(item)), 0);
      let r = this.rand() * total;
      for (const item of items) {
        r -= Math.max(0.0001, weightFn(item));
        if (r <= 0) return item;
      }
      return items[items.length - 1];
    }

    archetypeFamily(name) {
      for (const family of Object.keys(archetypeCatalog)) {
        if (archetypeCatalog[family].indexOf(name) >= 0) return family;
      }
      return 'foundational';
    }

    compatibleArchetypes(primary) {
      const family = this.archetypeFamily(primary);
      const combined = [];
      if (family === 'foundational') {
        combined.push('RingStack', 'RadialGrid', 'RadialCanopy', 'Dihedral', 'TerracedStack');
      } else if (family === 'derived') {
        combined.push('Stack', 'Grid', 'Dihedral', 'RecursiveRing', 'TerracedStack');
      } else if (family === 'architectural') {
        combined.push('Grid', 'Band', 'Ring', 'Spokes', 'Dihedral');
      } else {
        combined.push('Ring', 'Spokes', 'Stack', 'Band');
      }
      return combined.filter((name, idx, arr) => name !== primary && arr.indexOf(name) === idx);
    }

    pickDepth() {
      const raw = String(this.options.depth || 'random');
      const fixed = Number(raw);
      if (Number.isInteger(fixed) && fixed > 0) return fixed;
      return this.randInt(4, 7);
    }

    pickOverlapMode() {
      const raw = String(this.options.overlap || 'joined').toLowerCase();
      return overlapMap[raw] != null ? raw : 'joined';
    }

    pickOverlapRatio() {
      return overlapMap[this.pickOverlapMode()] ?? overlapMap.joined;
    }

    pickPrimaryArchetype() {
      const all = Object.values(archetypeCatalog).flat();
      return this.weightedPick(all, (name) => {
        const family = this.archetypeFamily(name);
        return familyWeights[family] || 1;
      });
    }

    makeTitle(primary, secondary) {
      const lead = this.pick(titleLeads[primary] || titleLeads.Stack);
      const accent = this.pick(titleLeads[secondary] || titleLeads.Grid);
      const tail = this.pick(titleTails);
      return [lead, accent, tail].join(' ');
    }

    buildRule(name, lines) {
      return [name + ' ->'].concat(lines).join('\n');
    }

    pushBlock(lines, bodyLines) {
      lines.push('[');
      bodyLines.forEach((entry) => lines.push('  ' + entry));
      lines.push(']');
    }

    motifPrimitive(name) {
      switch (name) {
        case 'Stack':
        case 'TerracedStack':
          return 'CubeY';
        case 'Band':
        case 'Ribbon':
        case 'Spokes':
          return 'CubeX';
        case 'FacadeBandGrid':
          return 'CubeZ';
        default:
          return 'Cube';
      }
    }

    buildArchetypeRule(index, level) {
      const lines = [];
      const primitive = this.motifPrimitive(level.archetype);
      const r = level.r;
      const h = level.h;
      const overlap = level.overlap;
      const accent = level.accentTexture;
      const radius = r * (2.55 - overlap * 0.55);
      const ringStep = r * (0.95 - overlap * 0.16);
      const liftStep = h * (0.18 - overlap * 0.025);
      const addRing = (count, ringRadius, y, scale) => {
        for (let k = 0; k < count; k += 1) {
          this.pushBlock(lines, [
            'A ( ' + formatNum((360 * k) / count) + ' 1 )',
            'T ( ' + formatNum(ringRadius) + ' ' + formatNum(y) + ' 0 )',
            'S ( ' + formatNum(scale) + ' ' + formatNum(scale * 0.42) + ' ' + formatNum(scale) + ' )',
            'I ( Cube ' + accent + ' ' + formatNum(Math.max(0.10, scale * 0.45)) + ' )'
          ]);
        }
      };
      const addSpokes = (count, spokeRadius, y, xScale, zScale) => {
        for (let k = 0; k < count; k += 1) {
          this.pushBlock(lines, [
            'A ( ' + formatNum((360 * k) / count) + ' 1 )',
            'T ( ' + formatNum(spokeRadius) + ' ' + formatNum(y) + ' 0 )',
            'S ( ' + formatNum(xScale) + ' ' + formatNum(r * 0.18) + ' ' + formatNum(zScale) + ' )',
            'I ( CubeX ' + accent + ' ' + formatNum(Math.max(0.11, zScale * 0.44)) + ' )'
          ]);
        }
      };

      switch (level.archetype) {
        case 'Stack': {
          const step = r * (0.62 - overlap * 0.18);
          for (let k = 0; k < level.stackN; k += 1) {
            this.pushBlock(lines, [
              'T ( 0 ' + formatNum(k * step) + ' 0 )',
              'S ( ' + formatNum(r * 0.72) + ' ' + formatNum(r * 0.38) + ' ' + formatNum(r * 0.72) + ' )',
              'I ( ' + primitive + ' ' + accent + ' ' + formatNum(Math.max(0.14, r * 0.42)) + ' )'
            ]);
          }
          break;
        }
        case 'Ring': {
          addRing(level.ringN, radius, 0, r * 0.64);
          break;
        }
        case 'Spokes': {
          addSpokes(level.spokeN, h * 0.14 + r * 1.55, 0, r * 1.45, r * 0.46);
          break;
        }
        case 'Band': {
          const span = h * 0.28 + r * 1.55;
          const step = level.bandN > 1 ? span / (level.bandN - 1) : 0;
          for (let k = 0; k < level.bandN; k += 1) {
            this.pushBlock(lines, [
              'T ( ' + formatNum((-span * 0.5) + (k * step)) + ' 0 0 )',
              'S ( ' + formatNum(r * 0.68) + ' ' + formatNum(r * 0.22) + ' ' + formatNum(r * 0.62) + ' )',
              'I ( ' + primitive + ' ' + accent + ' ' + formatNum(Math.max(0.12, r * 0.28)) + ' )'
            ]);
          }
          break;
        }
        case 'Grid': {
          const span = r * 1.18;
          const half = (level.gridN - 1) * 0.5;
          for (let gx = 0; gx < level.gridN; gx += 1) {
            for (let gz = 0; gz < level.gridN; gz += 1) {
              this.pushBlock(lines, [
                'T ( ' + formatNum((gx - half) * span) + ' 0 ' + formatNum((gz - half) * span) + ' )',
                'S ( ' + formatNum(r * 0.50) + ' ' + formatNum(r * 0.16) + ' ' + formatNum(r * 0.50) + ' )',
                'I ( Cube ' + accent + ' ' + formatNum(Math.max(0.11, r * 0.26)) + ' )'
              ]);
            }
          }
          break;
        }
        case 'RingStack': {
          const ringLayers = Math.max(2, Math.min(4, level.stackN));
          for (let layer = 0; layer < ringLayers; layer += 1) {
            addRing(level.ringN + layer, radius * (1 - layer * 0.05), layer * ringStep, r * (0.60 - layer * 0.06));
          }
          break;
        }
        case 'Spiral': {
          const segs = Math.max(8, level.bandN * 3);
          const turns = 1.15 + (level.depthIndex * 0.12);
          for (let k = 0; k < segs; k += 1) {
            const t = segs > 1 ? k / (segs - 1) : 0;
            this.pushBlock(lines, [
              'A ( ' + formatNum(360 * turns * t) + ' 1 )',
              'T ( ' + formatNum(radius * (0.78 + t * 0.24)) + ' ' + formatNum(t * h * 0.72) + ' 0 )',
              'S ( ' + formatNum(r * 0.56) + ' ' + formatNum(r * 0.18) + ' ' + formatNum(r * 0.42) + ' )',
              'I ( CubeX ' + accent + ' ' + formatNum(Math.max(0.11, r * 0.22)) + ' )'
            ]);
          }
          break;
        }
        case 'Fork': {
          const branchCount = level.forkMode === 3 ? 3 : 2;
          const branchAngles = branchCount === 3 ? [-level.yawA, 0, level.yawB] : [-level.yawA, level.yawB];
          branchAngles.forEach((ang, idx) => {
            this.pushBlock(lines, [
              'A ( ' + formatNum(ang) + ' 2 )',
              'A ( ' + formatNum(idx % 2 === 0 ? 18 : 12) + ' 0 )',
              'T ( 0 ' + formatNum(h * 0.10) + ' 0 )',
              'S ( ' + formatNum(r * 0.52) + ' ' + formatNum(r * 1.12) + ' ' + formatNum(r * 0.52) + ' )',
              'I ( CubeY ' + accent + ' ' + formatNum(Math.max(0.12, r * 0.30)) + ' )'
            ]);
          });
          break;
        }
        case 'RadialGrid': {
          addSpokes(level.spokeN, radius * 1.10, 0, r * 1.58, r * 0.40);
          for (let ringLayer = 1; ringLayer <= Math.max(2, Math.min(4, level.gridN + 1)); ringLayer += 1) {
            addRing(level.spokeN, ringLayer * r * 0.95, 0, r * 0.36);
          }
          break;
        }
        case 'Ribbon': {
          const segs = Math.max(5, level.bandN + 2);
          const span = radius * 1.85;
          const step = segs > 1 ? span / (segs - 1) : 0;
          for (let k = 0; k < segs; k += 1) {
            const x = (-span * 0.5) + (k * step);
            const y = Math.sin((k / Math.max(1, segs - 1)) * Math.PI) * h * 0.24;
            const z = Math.cos((k / Math.max(1, segs - 1)) * Math.PI) * r * 0.42;
            this.pushBlock(lines, [
              'A ( ' + formatNum(-18 + k * (36 / Math.max(1, segs - 1))) + ' 1 )',
              'T ( ' + formatNum(x) + ' ' + formatNum(y) + ' ' + formatNum(z) + ' )',
              'S ( ' + formatNum(r * 0.82) + ' ' + formatNum(r * 0.18) + ' ' + formatNum(r * 0.36) + ' )',
              'I ( CubeX ' + accent + ' ' + formatNum(Math.max(0.11, r * 0.22)) + ' )'
            ]);
          }
          break;
        }
        case 'TerracedStack': {
          const floors = Math.max(3, level.stackN + 1);
          for (let floor = 0; floor < floors; floor += 1) {
            const s = Math.pow(0.90, floor);
            this.pushBlock(lines, [
              'T ( 0 ' + formatNum(floor * (r * 0.54)) + ' 0 )',
              'S ( ' + formatNum(r * 1.22 * s) + ' ' + formatNum(r * 0.34) + ' ' + formatNum(r * 1.22 * s) + ' )',
              'I ( Cube ' + accent + ' ' + formatNum(Math.max(0.12, r * 0.28 * s)) + ' )'
            ]);
          }
          break;
        }
        case 'FacadeBandGrid': {
          const rows = Math.max(2, level.gridN + 1);
          const cols = Math.max(3, level.bandN + 1);
          const colStep = r * 0.96;
          const rowStep = r * 0.54;
          for (let row = 0; row < rows; row += 1) {
            for (let col = 0; col < cols; col += 1) {
              this.pushBlock(lines, [
                'T ( ' + formatNum((col - (cols - 1) * 0.5) * colStep) + ' ' + formatNum(row * rowStep) + ' 0 )',
                'S ( ' + formatNum(r * 0.42) + ' ' + formatNum(r * 0.30) + ' ' + formatNum(r * 0.18) + ' )',
                'I ( CubeZ ' + accent + ' ' + formatNum(Math.max(0.10, r * 0.20)) + ' )'
              ]);
            }
          }
          for (let row = 0; row < rows; row += 1) {
            this.pushBlock(lines, [
              'T ( 0 ' + formatNum(row * rowStep) + ' 0 )',
              'S ( ' + formatNum(cols * colStep * 0.55) + ' ' + formatNum(r * 0.10) + ' ' + formatNum(r * 0.10) + ' )',
              'I ( CubeX ' + accent + ' ' + formatNum(Math.max(0.10, r * 0.16)) + ' )'
            ]);
          }
          break;
        }
        case 'VaultedRingGrid': {
          const cols = Math.max(4, level.bandN + 2);
          const span = radius * 1.55;
          const step = cols > 1 ? span / (cols - 1) : 0;
          for (let k = 0; k < cols; k += 1) {
            const t = cols > 1 ? k / (cols - 1) : 0.5;
            const x = (-span * 0.5) + (k * step);
            const y = (1 - Math.pow((t - 0.5) * 2, 2)) * h * 0.26;
            this.pushBlock(lines, [
              'T ( ' + formatNum(x) + ' ' + formatNum(y) + ' 0 )',
              'S ( ' + formatNum(r * 0.34) + ' ' + formatNum(r * 0.26) + ' ' + formatNum(r * 0.34) + ' )',
              'I ( Cube ' + accent + ' ' + formatNum(Math.max(0.10, r * 0.18)) + ' )'
            ]);
          }
          addRing(Math.max(8, level.ringN), radius * 0.86, h * 0.18, r * 0.30);
          break;
        }
        case 'RadialCanopy': {
          const rings = Math.max(2, Math.min(4, level.gridN + 1));
          for (let layer = 0; layer < rings; layer += 1) {
            addRing(level.spokeN + layer, radius * (0.65 + layer * 0.20), layer * liftStep, r * (0.42 - layer * 0.03));
          }
          addSpokes(level.spokeN, radius * 0.95, h * 0.20, r * 1.35, r * 0.34);
          break;
        }
        case 'RecursiveRing': {
          addRing(level.ringN, radius, 0, r * 0.54);
          addRing(Math.max(6, level.ringN - 2), radius * 0.54, h * 0.16, r * 0.32);
          if (level.depthIndex > 1) addRing(Math.max(5, level.ringN - 4), radius * 0.28, h * 0.28, r * 0.20);
          break;
        }
        case 'Dihedral': {
          const lobes = Math.max(2, Math.min(5, level.gridN + 1));
          for (let k = 0; k < lobes; k += 1) {
            const ang = (360 * k) / lobes;
            this.pushBlock(lines, [
              'A ( ' + formatNum(ang) + ' 1 )',
              'T ( ' + formatNum(radius * 0.78) + ' 0 0 )',
              'S ( ' + formatNum(r * 1.04) + ' ' + formatNum(r * 0.20) + ' ' + formatNum(r * 0.40) + ' )',
              'I ( CubeX ' + accent + ' ' + formatNum(Math.max(0.11, r * 0.24)) + ' )'
            ]);
            this.pushBlock(lines, [
              'A ( ' + formatNum(ang + 180 / lobes) + ' 1 )',
              'T ( ' + formatNum(-radius * 0.62) + ' 0 0 )',
              'S ( ' + formatNum(r * 0.82) + ' ' + formatNum(r * 0.18) + ' ' + formatNum(r * 0.34) + ' )',
              'I ( CubeX ' + accent + ' ' + formatNum(Math.max(0.10, r * 0.22)) + ' )'
            ]);
          }
          break;
        }
        default: {
          this.pushBlock(lines, [
            'S ( ' + formatNum(r * 0.64) + ' ' + formatNum(r * 0.24) + ' ' + formatNum(r * 0.64) + ' )',
            'I ( Cube ' + accent + ' ' + formatNum(Math.max(0.11, r * 0.24)) + ' )'
          ]);
        }
      }
      return this.buildRule('Motif' + index, lines);
    }

    generate() {
      const depth = this.pickDepth();
      const overlapMode = this.pickOverlapMode();
      const overlapRatio = this.pickOverlapRatio();
      const primaryArchetype = this.pickPrimaryArchetype();
      const secondaryArchetype = this.pick(this.compatibleArchetypes(primaryArchetype));
      const familySignature = this.archetypeFamily(primaryArchetype) + ' → ' + this.archetypeFamily(secondaryArchetype);
      const baseH = this.randFloat(2.8, 4.8);
      const baseR = this.randFloat(0.38, 0.72);
      const shrinkH = this.randFloat(0.76, 0.88);
      const shrinkR = this.randFloat(0.70, 0.84);
      const primaryTexture = this.pick(texturePool);
      const accentTexture = this.pick(texturePool);
      const crownTexture = this.pick(texturePool);
      const textureSet = primaryTexture + ' / ' + accentTexture + ' / ' + crownTexture;
      const basePlinthH = Math.max(0.34, baseH * (0.18 + overlapRatio * 0.10));
      const basePlinthR = baseR * (3.2 + overlapRatio * 1.6);
      const baseCapH = basePlinthH * 0.52;
      const baseCapR = basePlinthR * 0.78;
      const trunkStartY = (basePlinthH + baseCapH) - (baseCapH * (0.30 + overlapRatio * 0.35));
      const motifs = [];
      const forks = [];
      const levels = [];
      const out = [];

      const foundationalCycle = archetypeCatalog.foundational;
      const accentCycle = [primaryArchetype, secondaryArchetype].concat(foundationalCycle.filter((name) => name !== primaryArchetype && name !== secondaryArchetype));

      for (let i = 0; i < depth; i += 1) {
        const h = baseH * Math.pow(shrinkH, i);
        const r = baseR * Math.pow(shrinkR, i);
        let archetype = i === 0 ? primaryArchetype : accentCycle[(i + 1) % accentCycle.length];
        if (i === depth - 1) archetype = secondaryArchetype;
        if (i > 1 && this.rand() > 0.66) archetype = this.pick(accentCycle);
        const forkMode = this.rand() > 0.45 ? 3 : 2;
        motifs.push(archetype);
        forks.push(forkMode);
        levels.push({
          h: h,
          r: r,
          archetype: archetype,
          forkMode: forkMode,
          ringN: this.randInt(6 + i, 10 + i * 2),
          spokeN: this.randInt(4 + i, 8 + i * 2),
          bandN: this.randInt(3 + i, 6 + i),
          stackN: this.randInt(2 + i, 4 + i),
          gridN: this.randInt(2, 3 + Math.min(i, 2)),
          yawA: this.randInt(14, 32),
          yawB: this.randInt(16, 36),
          pitchC: this.randInt(8, 20),
          trunkTexture: primaryTexture,
          accentTexture: accentTexture,
          crownTexture: crownTexture,
          overlap: overlapRatio,
          depthIndex: i
        });
      }

      const title = this.makeTitle(primaryArchetype, secondaryArchetype);
      const line = function (s) { out.push(s); };

      line('// Progen3D archetype-driven grammar');
      line('// Title: ' + title);
      line('// Seed: ' + this.initialSeed);
      line('// Primary archetype: ' + primaryArchetype);
      line('// Secondary archetype: ' + secondaryArchetype);
      line('// Level motifs: ' + motifs.join(', '));
      line('// Families: ' + familySignature);
      line('// Cube join: ' + overlapLabels[overlapMode] + ' (' + formatNum(overlapRatio) + ' overlap ratio)');
      line('// Base: generated plinth and cap under the trunk');
      line('// Reference basis: foundational, derived, architectural, fractal, and symmetry motif families.');
      line('');
      line('Start -> [ Base ] [ T ( 0 ' + formatNum(trunkStartY) + ' 0 ) Trunk0 ]');
      line('');
      line(this.buildRule('Base', [
        '[',
        '  T ( 0 ' + formatNum(basePlinthH * 0.5) + ' 0 )',
        '  S ( ' + formatNum(basePlinthR) + ' ' + formatNum(basePlinthH) + ' ' + formatNum(basePlinthR) + ' )',
        '  I ( Cube ' + primaryTexture + ' ' + formatNum(Math.max(0.20, baseR * 0.64)) + ' )',
        ']',
        '[',
        '  T ( 0 ' + formatNum(basePlinthH + (baseCapH * 0.5)) + ' 0 )',
        '  S ( ' + formatNum(baseCapR) + ' ' + formatNum(baseCapH) + ' ' + formatNum(baseCapR) + ' )',
        '  I ( Cube ' + accentTexture + ' ' + formatNum(Math.max(0.16, baseR * 0.46)) + ' )',
        ']'
      ]));
      line('');

      for (let i = 0; i < depth; i += 1) {
        const level = levels[i];
        const nextRule = i < depth - 1 ? 'Trunk' + (i + 1) : 'Crown' + i;
        const motifAnchor = level.h * (1 - (0.10 + overlapRatio * 0.12));
        const forkAnchor = level.h * (1 - (0.06 + overlapRatio * 0.10));
        const branchEmbed = Math.max(level.r * 0.18, level.h * (0.10 + overlapRatio * 0.24));

        line(this.buildRule('Trunk' + i, [
          '[',
          '  T ( 0 ' + formatNum(level.h * 0.5) + ' 0 )',
          '  S ( ' + formatNum(level.r) + ' ' + formatNum(level.h) + ' ' + formatNum(level.r) + ' )',
          '  I ( CubeY ' + level.trunkTexture + ' ' + formatNum(Math.max(0.18, level.r * 0.54)) + ' )',
          ']',
          '[',
          '  T ( 0 ' + formatNum(motifAnchor) + ' 0 )',
          '  Motif' + i,
          ']',
          '[',
          '  T ( 0 ' + formatNum(forkAnchor) + ' 0 )',
          '  ForkChoice' + i,
          ']'
        ]));
        line('');

        if (i < depth - 1) {
          const preferredProb = level.forkMode === 3 ? 0.62 : 0.38;
          line('ForkChoice' + i + ' ; ' + formatNum(preferredProb) + ' -> TripleFork' + i + ' -> DoubleFork' + i);
          line('');

          line(this.buildRule('DoubleFork' + i, [
            '[',
            '  R yawL' + i + ' ( ' + (-level.yawA) + ' ' + (-Math.max(8, Math.round(level.yawA * 0.55))) + ' )',
            '  A ( yawL' + i + ' 2 )',
            '  T ( 0 ' + formatNum(-branchEmbed) + ' 0 )',
            '  ' + nextRule,
            ']',
            '[',
            '  R yawR' + i + ' ( ' + Math.max(8, Math.round(level.yawB * 0.55)) + ' ' + level.yawB + ' )',
            '  A ( yawR' + i + ' 2 )',
            '  T ( 0 ' + formatNum(-branchEmbed) + ' 0 )',
            '  ' + nextRule,
            ']'
          ]));
          line('');

          line(this.buildRule('TripleFork' + i, [
            '[',
            '  R yawL' + i + ' ( ' + (-level.yawA) + ' ' + (-Math.max(8, Math.round(level.yawA * 0.55))) + ' )',
            '  A ( yawL' + i + ' 2 )',
            '  T ( 0 ' + formatNum(-branchEmbed) + ' 0 )',
            '  ' + nextRule,
            ']',
            '[',
            '  R yawR' + i + ' ( ' + Math.max(8, Math.round(level.yawB * 0.55)) + ' ' + level.yawB + ' )',
            '  A ( yawR' + i + ' 2 )',
            '  T ( 0 ' + formatNum(-branchEmbed) + ' 0 )',
            '  ' + nextRule,
            ']',
            '[',
            '  R pitch' + i + ' ( ' + Math.max(4, Math.round(level.pitchC * 0.5)) + ' ' + level.pitchC + ' )',
            '  A ( pitch' + i + ' 0 )',
            '  T ( 0 ' + formatNum(-branchEmbed * 0.92) + ' 0 )',
            '  ' + nextRule,
            ']'
          ]));
          line('');
        } else {
          line('ForkChoice' + i + ' -> Crown' + i);
          line('');
        }

        line(this.buildRule('Crown' + i, [
          '[',
          '  S ( ' + formatNum(level.r * 2.25) + ' ' + formatNum(level.r * 0.95) + ' ' + formatNum(level.r * 2.25) + ' )',
          '  I ( Cube ' + level.crownTexture + ' ' + formatNum(Math.max(0.16, level.r * 0.52)) + ' )',
          ']',
          '[',
          '  A ( 45 1 )',
          '  S ( ' + formatNum(level.r * 1.65) + ' ' + formatNum(level.r * 0.42) + ' ' + formatNum(level.r * 1.65) + ' )',
          '  I ( Cube ' + level.accentTexture + ' ' + formatNum(Math.max(0.14, level.r * 0.34)) + ' )',
          ']'
        ]));
        line('');

        line(this.buildArchetypeRule(i, level));
        line('');
      }

      return {
        title: title,
        grammar: out.join('\n'),
        motifs: motifs,
        forks: forks,
        depth: depth,
        seed: this.initialSeed,
        textureSet: textureSet,
        overlapLabel: overlapLabels[overlapMode] || 'Joined',
        overlapRatio: overlapRatio,
        primaryArchetype: primaryArchetype,
        secondaryArchetype: secondaryArchetype,
        familySignature: familySignature
      };
    }
  }

  function scheduleValidation(draftId, delayMs) {
    window.setTimeout(function () {
      const draft = draftStore.get(draftId);
      if (!draft) return;
      draft.status = 'checking';
      draft.validationMessage = 'Running parser check...';
      renderScripts();
      const result = validateGrammarWithParser(draft.grammar);
      draft.validationRuns += 1;
      if (result.ok) {
        draft.status = 'valid';
        draft.validationMessage = result.message;
        draft.cubeCount = result.cubes;
        draft.retryTimer = null;
        renderScripts();
        return;
      }
      draft.cubeCount = 0;
      draft.errorCount += 1;
      draft.validationMessage = result.message;
      if (draft.errorCount >= MAX_ERROR_RETRIES) {
        draft.status = 'halted';
        renderScripts();
        return;
      }
      draft.status = 'retrying';
      renderScripts();
      draft.retryTimer = window.setTimeout(function () {
        regenerateDraft(draftId);
      }, REGENERATE_DELAY_MS);
    }, delayMs);
  }

  function regenerateDraft(draftId) {
    const draft = draftStore.get(draftId);
    if (!draft || draft.errorCount >= MAX_ERROR_RETRIES) return;
    if (draft.retryTimer) {
      clearTimeout(draft.retryTimer);
      draft.retryTimer = null;
    }
    draft.regenerationIndex += 1;
    const writer = new OrganicGrammarWriter(nextSeed(draft.baseSeed, draft.regenerationIndex), {
      depth: draft.requestedDepth,
      overlap: draft.requestedOverlap
    });
    const updated = writer.generate();
    draft.title = updated.title;
    draft.grammar = updated.grammar;
    draft.motifs = updated.motifs;
    draft.forks = updated.forks;
    draft.depth = updated.depth;
    draft.seed = updated.seed;
    draft.textureSet = updated.textureSet;
    draft.overlapLabel = updated.overlapLabel;
    draft.overlapRatio = updated.overlapRatio;
    draft.primaryArchetype = updated.primaryArchetype;
    draft.secondaryArchetype = updated.secondaryArchetype;
    draft.familySignature = updated.familySignature;
    draft.status = 'checking';
    draft.validationMessage = 'Regenerated after parser error. Rechecking...';
    renderScripts();
    scheduleValidation(draftId, 60);
  }

  function makeDraft(seed, requestedDepth, requestedOverlap) {
    const writer = new OrganicGrammarWriter(seed, { depth: requestedDepth, overlap: requestedOverlap });
    const generated = writer.generate();
    return Object.assign({
      id: 'writer-draft-' + generationSerial + '-' + draftOrder.length,
      baseSeed: seed,
      requestedDepth: requestedDepth,
      requestedOverlap: requestedOverlap,
      regenerationIndex: 0,
      validationRuns: 0,
      errorCount: 0,
      cubeCount: 0,
      status: 'checking',
      validationMessage: 'Queued for parser check...',
      retryTimer: null
    }, generated);
  }

  function generateSet() {
    generationSerial += 1;
    clearDraftTimers();
    draftOrder.length = 0;
    draftStore.clear();
    const baseSeed = Number(seedInput.value || Date.now()) >>> 0;
    const count = Math.max(1, Number(countInput.value || 4));
    const requestedDepth = depthInput.value || 'random';
    const requestedOverlap = overlapInput ? (overlapInput.value || 'joined') : 'joined';
    for (let i = 0; i < count; i += 1) {
      const draft = makeDraft(nextSeed(baseSeed, i), requestedDepth, requestedOverlap);
      draftOrder.push(draft.id);
      draftStore.set(draft.id, draft);
    }
    renderScripts();
    draftOrder.forEach(function (id, idx) {
      scheduleValidation(id, 80 + idx * 40);
    });
  }

  function copyGrammar(button) {
    const text = button.getAttribute('data-grammar') || '';
    const original = button.getAttribute('data-copy-label') || button.textContent;
    const done = function () {
      button.textContent = 'Copied';
      window.setTimeout(function () { button.textContent = original; }, 1400);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done).catch(function () {});
      return;
    }
    const area = document.createElement('textarea');
    area.value = text;
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    area.remove();
    done();
  }

  generateBtn.addEventListener('click', generateSet);
  randomSeedBtn.addEventListener('click', function () {
    seedInput.value = String((Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0);
    generateSet();
  });

  resultsEl.addEventListener('click', function (event) {
    const copyBtn = event.target.closest('.js-copy-writer');
    if (copyBtn) {
      copyGrammar(copyBtn);
      return;
    }
    const openLink = event.target.closest('.js-open-writer');
    if (openLink && openLink.classList.contains('is-disabled')) {
      event.preventDefault();
      return;
    }
    if (openLink) {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify({
          title: openLink.getAttribute('data-title') || 'Generated grammar',
          content: openLink.getAttribute('data-grammar') || ''
        }));
      } catch (error) {}
    }
  });

  seedInput.value = String((Date.now() >>> 0));
  generateSet();
})();
