(function () {
  'use strict';

  const config = window.intelligentWriterConfig || {};
  const STORAGE_KEY = config.storageKey || 'p3d_writer_draft_v1';
  const MAX_ERROR_RETRIES = 10;
  const REGENERATE_DELAY_MS = 10000;
  const resultsEl = document.getElementById('intelligentWriterResults');
  const promptInput = document.getElementById('intelligentWriterPrompt');
  const countInput = document.getElementById('intelligentWriterCount');
  const depthInput = document.getElementById('intelligentWriterDepth');
  const overlapInput = document.getElementById('intelligentWriterOverlap');
  const generateBtn = document.getElementById('intelligentWriterGenerateBtn');
  const exampleBtn = document.getElementById('intelligentWriterPromptExampleBtn');
  if (!resultsEl || !promptInput || !countInput || !depthInput || !overlapInput || !generateBtn || !exampleBtn) return;

  const examplePrompt = 'Design a dihedral pavilion lamp with a stepped base, ring canopy, upward radial ribs, and layered lamp-shade parts. Research equations for the canopy flare, rib spacing, and shade curvature, then assemble those parts into a joined overlapping cube structure that feels architectural and elegant.';
  const draftOrder = [];
  const draftStore = new Map();
  let generationSerial = 0;

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, function (ch) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch] || ch;
    });
  }

  function clearValidationState() {
    if (typeof variable_list !== 'undefined' && Array.isArray(variable_list)) variable_list.length = 0;
    if (typeof full_variable_list !== 'undefined' && Array.isArray(full_variable_list)) full_variable_list.length = 0;
  }

  function countGeneratedCubes(grammar) {
    if (!grammar || !Array.isArray(grammar.tokens_new)) return 0;
    let total = 0;
    for (const tok of grammar.tokens_new) {
      if (!tok || tok.token_name !== 'I') continue;
      if (String(tok.instance_type || '').indexOf('Cube') === 0) {
        total += Math.max(1, Number(tok.instance_count || 1));
      }
    }
    return total;
  }

  function normalizeParserError(grammarText, err) {
    const safeText = String(grammarText || '');
    const safeErr = err || {};
    const line = Number.isFinite(Number(safeErr.line)) ? Number(safeErr.line) : null;
    const col = Number.isFinite(Number(safeErr.col)) ? Number(safeErr.col) : null;
    const snippet = typeof safeErr.snippet === 'string' ? safeErr.snippet.trim() : '';
    const message = safeErr && safeErr.message ? String(safeErr.message) : 'Unknown grammar parser error.';
    const lines = safeText.replace(/\r/g, '').split('\n');
    let sourceLine = '';
    if (line && line >= 1 && line <= lines.length) {
      sourceLine = lines[line - 1];
    } else if (snippet) {
      sourceLine = snippet.replace(/\r/g, '').split('\n')[0] || '';
    }
    const parts = [];
    if (line !== null && col !== null) {
      parts.push(message + ' (line ' + line + ', col ' + col + ')');
    } else if (line !== null) {
      parts.push(message + ' (line ' + line + ')');
    } else {
      parts.push(message);
    }
    if (sourceLine) {
      parts.push(sourceLine);
      if (col !== null) {
        parts.push(new Array(Math.max(0, col) + 1).join(' ') + '^');
      }
    } else if (snippet) {
      parts.push(snippet);
    }
    return {
      ok: false,
      message: parts.join('\n'),
      cubes: 0,
      errorDetails: {
        name: safeErr && safeErr.name ? String(safeErr.name) : 'ParseError',
        message: message,
        line: line,
        col: col,
        snippet: snippet,
        source_line: sourceLine
      }
    };
  }

  function validateGrammarWithParser(grammarText) {
    const trimmed = String(grammarText || '').trim();
    if (!trimmed) {
      return {
        ok: false,
        message: 'Empty grammar draft.',
        cubes: 0,
        errorDetails: { name: 'ParseError', message: 'Empty grammar draft.', line: null, col: null, snippet: '', source_line: '' }
      };
    }
    if (typeof Grammar !== 'function') {
      return {
        ok: false,
        message: 'Grammar parser is not available on this page.',
        cubes: 0,
        errorDetails: { name: 'ParserUnavailable', message: 'Grammar parser is not available on this page.', line: null, col: null, snippet: '', source_line: '' }
      };
    }
    try {
      clearValidationState();
      if (typeof RNG !== 'undefined' && RNG && typeof RNG.setSeed === 'function') {
        RNG.setSeed(Date.now() >>> 0);
      }
      const grammar = new Grammar(trimmed);
      return { ok: true, message: 'Parser check passed.', cubes: countGeneratedCubes(grammar), errorDetails: null };
    } catch (err) {
      return normalizeParserError(trimmed, err);
    }
  }

  function statusLabel(status) {
    switch (status) {
      case 'queued': return 'Queued';
      case 'generating': return 'Generating';
      case 'valid': return '✓ Error free';
      case 'invalid': return 'Parser error';
      case 'retrying': return 'Retry queued';
      case 'halted': return 'Stopped';
      case 'api-error': return 'API error';
      default: return 'Checking';
    }
  }

  function clearDraftTimers() {
    draftStore.forEach(function (draft) {
      if (draft.retryTimer) {
        clearTimeout(draft.retryTimer);
        draft.retryTimer = null;
      }
    });
  }

  function renderDrafts() {
    resultsEl.innerHTML = draftOrder.map(function (id, index) {
      const item = draftStore.get(id);
      if (!item) return '';
      const tags = (item.motifs || []).map(function (motif) {
        return '<span class="example-tag">' + escapeHtml(motif) + '</span>';
      }).join('');
      const equationList = (item.equations || []).map(function (eq) {
        return '<li><code>' + escapeHtml(eq) + '</code></li>';
      }).join('');
      const openDisabled = item.status !== 'valid';
      const cubeSummary = item.status === 'valid' ? ' · cubes ' + escapeHtml(item.cubeCount) : '';
      const errorSummary = item.errorCount > 0 ? ' · parser errors ' + escapeHtml(item.errorCount) + '/' + MAX_ERROR_RETRIES : '';
      const attemptSummary = ' · attempt ' + escapeHtml(item.attempt);
      const promptSummary = item.prompt ? '<p class="writer-prompt-echo">' + escapeHtml(item.prompt) + '</p>' : '';
      return [
        '<article class="writer-card panel">',
        '  <div class="writer-card__head">',
        '    <div>',
        '      <span class="page-kicker">Draft ' + (index + 1) + '</span>',
        '      <h3>' + escapeHtml(item.title || ('Prompt draft ' + (index + 1))) + '</h3>',
        '      <p>Depth ' + escapeHtml(item.depth) + ' · join ' + escapeHtml(item.overlap) + ' · primary ' + escapeHtml(item.primaryArchetype || 'Hybrid') + ' · secondary ' + escapeHtml(item.secondaryArchetype || 'Support') + ' · model ' + escapeHtml(item.model || 'OpenAI') + '</p>',
        promptSummary,
        '    </div>',
        '    <div class="writer-card__actions">',
        '      <button class="btn btn-secondary btn-sm js-copy-intelligent" type="button" data-copy-label="Copy grammar" data-grammar="' + escapeHtml(item.grammar || '') + '">Copy grammar</button>',
        '      <a class="btn btn-primary btn-sm js-open-intelligent' + (openDisabled ? ' is-disabled' : '') + '" href="editor.php"' + (openDisabled ? ' aria-disabled="true" tabindex="-1"' : '') + ' data-title="' + escapeHtml(item.title || 'Intelligent draft') + '" data-grammar="' + escapeHtml(item.grammar || '') + '">Open in editor</a>',
        '    </div>',
        '  </div>',
        '  <div class="writer-card__validation">',
        '    <span class="writer-status writer-status--' + escapeHtml(item.status) + '">' + escapeHtml(statusLabel(item.status)) + '</span>',
        '    <p class="writer-validation-message">' + escapeHtml(item.validationMessage || 'Waiting...') + '</p>',
        '    <p class="writer-validation-detail">Checks run ' + escapeHtml(item.validationRuns || 0) + cubeSummary + errorSummary + attemptSummary + '</p>',
        '  </div>',
        '  <div class="writer-card__meta">' + tags + '<span class="example-tag">' + escapeHtml(item.familySignature || 'Prompt-driven hybrid') + '</span></div>',
        '  <pre class="example-code writer-code"><code>' + escapeHtml(item.grammar || '') + '</code></pre>',
        '</article>'
      ].join('');
    }).join('');
  }

  function copyGrammar(button) {
    const text = button.getAttribute('data-grammar') || '';
    const original = button.getAttribute('data-copy-label') || button.textContent;
    const done = function () {
      button.textContent = 'Copied';
      window.setTimeout(function () { button.textContent = original; }, 1400);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done).catch(function () {});
      return;
    }
    const area = document.createElement('textarea');
    area.value = text;
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    area.remove();
    done();
  }

  async function requestDraft(draft) {
    draft.status = 'generating';
    draft.validationMessage = draft.attempt === 1 ? 'Researching shape equations, parts, and grammar...' : 'Retrying with parser feedback and refreshed shape research...';
    renderDrafts();
    const response = await fetch('api/intelligent_writer.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-CSRF-Token': config.csrfToken || ''
      },
      body: JSON.stringify({
        prompt: draft.prompt,
        depth: draft.depth,
        overlap: draft.overlap,
        attempt: draft.attempt,
        variant: draft.variant,
        previous_error: draft.lastParserError || '',
        previous_error_details: draft.lastParserErrorDetails || null,
        previous_grammar: draft.lastFailedGrammar || ''
      })
    });
    const data = await response.json().catch(function () { return {}; });
    if (!response.ok || !data.ok || !data.draft) {
      throw new Error(data.error || 'Intelligent Writer request failed.');
    }
    return data.draft;
  }

  function scheduleRetry(draft) {
    draft.status = 'retrying';
    draft.validationMessage = 'Parser error. Regenerating in 10 seconds...';
    renderDrafts();
    draft.retryTimer = window.setTimeout(function () {
      draft.retryTimer = null;
      runDraft(draft.id);
    }, REGENERATE_DELAY_MS);
  }

  async function runDraft(draftId) {
    const draft = draftStore.get(draftId);
    if (!draft) return;
    if (draft.errorCount >= MAX_ERROR_RETRIES) {
      draft.status = 'halted';
      draft.validationMessage = 'Stopped after 10 parser errors.';
      renderDrafts();
      return;
    }
    try {
      const apiDraft = await requestDraft(draft);
      draft.title = apiDraft.title || draft.title;
      draft.grammar = apiDraft.grammar || '';
      draft.primaryArchetype = apiDraft.primary_archetype || 'Hybrid';
      draft.secondaryArchetype = apiDraft.secondary_archetype || 'Support';
      draft.familySignature = apiDraft.family_signature || 'Prompt-driven hybrid';
      draft.motifs = Array.isArray(apiDraft.motifs) ? apiDraft.motifs : [];
      draft.equations = [];
      draft.model = apiDraft.model || draft.model;
      draft.status = 'checking';
      draft.validationMessage = 'Running parser check...';
      renderDrafts();
      const result = validateGrammarWithParser(draft.grammar);
      draft.validationRuns += 1;
      if (result.ok) {
        draft.status = 'valid';
        draft.validationMessage = result.message;
        draft.cubeCount = result.cubes;
        renderDrafts();
        return;
      }
      draft.errorCount += 1;
      draft.cubeCount = 0;
      draft.lastParserError = result.message;
      draft.lastParserErrorDetails = result.errorDetails || null;
      draft.lastFailedGrammar = draft.grammar || '';
      draft.validationMessage = result.message;
      draft.attempt += 1;
      if (draft.errorCount >= MAX_ERROR_RETRIES) {
        draft.status = 'halted';
        draft.validationMessage = result.message + ' Generation stopped after 10 parser errors.';
        renderDrafts();
        return;
      }
      scheduleRetry(draft);
    } catch (error) {
      draft.status = 'api-error';
      draft.validationMessage = error && error.message ? error.message : 'OpenAI request failed.';
      renderDrafts();
    }
  }

  function createDraft(index) {
    return {
      id: 'intelligent-draft-' + generationSerial + '-' + index,
      variant: index + 1,
      prompt: String(promptInput.value || '').trim(),
      depth: depthInput.value || 'random',
      overlap: overlapInput.value || 'joined',
      title: 'Prompt draft ' + (index + 1),
      grammar: '',
      primaryArchetype: 'Hybrid',
      secondaryArchetype: 'Support',
      familySignature: 'Prompt-driven hybrid',
      motifs: [],
      equations: [],
      model: 'OpenAI',
      attempt: 1,
      validationRuns: 0,
      errorCount: 0,
      cubeCount: 0,
      status: 'queued',
      validationMessage: 'Queued for generation...',
      lastParserError: '',
      lastParserErrorDetails: null,
      lastFailedGrammar: '',
      retryTimer: null
    };
  }

  function generateSet() {
    const prompt = String(promptInput.value || '').trim();
    if (!prompt) {
      promptInput.focus();
      return;
    }
    generationSerial += 1;
    clearDraftTimers();
    draftOrder.length = 0;
    draftStore.clear();
    const count = Math.max(1, Number(countInput.value || 3));
    for (let i = 0; i < count; i += 1) {
      const draft = createDraft(i);
      draftOrder.push(draft.id);
      draftStore.set(draft.id, draft);
    }
    renderDrafts();
    draftOrder.forEach(function (id, idx) {
      window.setTimeout(function () { runDraft(id); }, 60 + idx * 120);
    });
  }

  generateBtn.addEventListener('click', generateSet);
  exampleBtn.addEventListener('click', function () {
    promptInput.value = examplePrompt;
    generateSet();
  });

  resultsEl.addEventListener('click', function (event) {
    const copyBtn = event.target.closest('.js-copy-intelligent');
    if (copyBtn) {
      copyGrammar(copyBtn);
      return;
    }
    const openLink = event.target.closest('.js-open-intelligent');
    if (openLink && openLink.classList.contains('is-disabled')) {
      event.preventDefault();
      return;
    }
    if (openLink) {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify({
          title: openLink.getAttribute('data-title') || 'Intelligent draft',
          content: openLink.getAttribute('data-grammar') || ''
        }));
      } catch (error) {}
    }
  });

  if (!promptInput.value) {
    promptInput.value = examplePrompt;
  }
})();
