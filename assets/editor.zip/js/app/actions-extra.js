// Added in modular split: wire JSON import/export and randomize without duplicating save handlers
(function(){
  'use strict';
  const $ = (id) => document.getElementById(id);
  const src = $('src');
  const out = $('out');
  const status = $('status');
  const chooser = $('nameChooser');
  const openJsonBtn = $('openJsonBtn');
  const exportJsonBtn = $('exportJsonBtn');
  const randomBtn = $('btn-random');

  function setStatus(msg) { if (status) status.textContent = msg; }
  function info(msg) {
    if (!out) return;
    const line = document.createElement('div');
    line.className = 'console-line console-info';
    line.innerHTML = `<span class="console-time">[${new Date().toLocaleTimeString()}]</span><span class="console-msg"></span>`;
    line.querySelector('.console-msg').textContent = String(msg);
    out.appendChild(line);
    out.scrollTop = out.scrollHeight;
  }

  const saveAPI = window.PG3DLocalSaves || {};
  const loadSaves = () => (typeof saveAPI.loadSaves === 'function' ? saveAPI.loadSaves() : {});
  const persistSaves = (obj) => { if (typeof saveAPI.persistSaves === 'function') saveAPI.persistSaves(obj); };
  const refreshChooser = (selectedId) => { if (typeof saveAPI.refreshChooser === 'function') saveAPI.refreshChooser(selectedId); };

  exportJsonBtn?.addEventListener('click', () => {
    const saves = loadSaves();
    const blob = new Blob([JSON.stringify(saves, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'grammar_saves.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    setStatus('Exported.');
    info(`Exported ${Object.keys(saves).length} saved entries.`);
  });

  openJsonBtn?.addEventListener('click', () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json';
    input.onchange = (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        try {
          const imported = JSON.parse(String(evt.target?.result || '{}'));
          const current = loadSaves();
          const merged = { ...current, ...imported };
          persistSaves(merged);
          refreshChooser();
          setStatus('Imported.');
          info(`Imported ${Object.keys(imported).length} saved entries.`);
        } catch (err) {
          setStatus('Import failed.');
          info('Import failed: invalid JSON file.');
        }
      };
      reader.readAsText(file);
    };
    input.click();
  });

  randomBtn?.addEventListener('click', () => {
    if (typeof window.RVGG !== 'function') {
      setStatus('Randomizer unavailable.');
      info('Randomizer unavailable because RVGG is not loaded.');
      return;
    }
    try {
      const gen = new window.RVGG();
      const result = gen.generateValid(Date.now());
      if (src) {
        src.value = result.program || '';
        src.dispatchEvent(new Event('input', { bubbles: true }));
      }
      setStatus('Randomized.');
      info(`Random grammar generated${result?.score != null ? ` (score ${result.score})` : ''}.`);
    } catch (err) {
      setStatus('Randomizer error.');
      info(`Randomizer error: ${err?.message || err}`);
    }
  });

  refreshChooser();
})();
