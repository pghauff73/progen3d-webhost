(function () {
  'use strict';

  const src = document.getElementById('src');
  const codewrap = document.getElementById('codewrap');
  const tip = document.getElementById('se-tooltip');
  const gutter = document.getElementById('lineGutter');
  const statusEl = document.getElementById('status');
  if (!src || !codewrap) return;

  const TOOLTIPS = {
    A: {
      label: 'Rotate operator',
      badge: 'Transform',
      syntax: 'A ( degrees axis )',
      desc: 'Rotate subsequent geometry by degrees around axis 0=X, 1=Y, 2=Z.',
      detail: 'Example: A ( 90 1 ) rotates 90 degrees around the Y axis.'
    },
    T: {
      label: 'Translate operator',
      badge: 'Transform',
      syntax: 'T ( x y z )',
      desc: 'Move subsequent geometry in world or local grammar space.',
      detail: 'Example: T ( 0 1.5 0 ) lifts the next instance upward.'
    },
    S: {
      label: 'Scale operator',
      badge: 'Transform',
      syntax: 'S ( sx sy sz )',
      desc: 'Scale following geometry uniformly or per axis.',
      detail: 'Example: S ( 1 3 1 ) creates a tall stretched volume.'
    },
    DS: {
      label: 'Dynamic scale',
      badge: 'Deform',
      syntax: 'DS ( sx sy sz )',
      desc: 'Applies dynamic scale factors derived from grammar variables.',
      detail: 'Useful for iteration-based tapering and procedural deformation.'
    },
    DT: {
      label: 'Delta translate',
      badge: 'Deform',
      syntax: 'DT ( x y z )',
      desc: 'Offsets translation with variable-aware grammar math.',
      detail: 'Often paired with DS to create stepped or tapered forms.'
    },
    DSX: {
      label: 'Axis deform scale X',
      badge: 'Axis deform',
      syntax: 'DSX ( x y z )',
      desc: 'Nested deformation scale around the X-axis frame.',
      detail: 'Use with DTX/DSY/DSZ for anisotropic procedural shaping.'
    },
    DSY: {
      label: 'Axis deform scale Y',
      badge: 'Axis deform',
      syntax: 'DSY ( x y z )',
      desc: 'Nested deformation scale around the Y-axis frame.',
      detail: 'Helpful for columns, towers, and vertically varying forms.'
    },
    DSZ: {
      label: 'Axis deform scale Z',
      badge: 'Axis deform',
      syntax: 'DSZ ( x y z )',
      desc: 'Nested deformation scale around the Z-axis frame.',
      detail: 'Commonly used for depth taper or span shaping.'
    },
    DTX: {
      label: 'Axis delta translate X',
      badge: 'Axis deform',
      syntax: 'DTX ( x y z )',
      desc: 'Nested deformation translation around the X-axis frame.',
      detail: 'Shifts geometry while staying within the rebased axis system.'
    },
    DTY: {
      label: 'Axis delta translate Y',
      badge: 'Axis deform',
      syntax: 'DTY ( x y z )',
      desc: 'Nested deformation translation around the Y-axis frame.',
      detail: 'Good for stacked offsets and lifted branching grammar.'
    },
    DTZ: {
      label: 'Axis delta translate Z',
      badge: 'Axis deform',
      syntax: 'DTZ ( x y z )',
      desc: 'Nested deformation translation around the Z-axis frame.',
      detail: 'Useful for forward/back sweep and span offsets.'
    },
    I: {
      label: 'Instantiate primitive',
      badge: 'Geometry',
      syntax: 'I ( Cube | CubeX | CubeY | CubeZ texture scale )',
      desc: 'Creates a primitive using the active transform stack.',
      detail: 'Example: I ( Cube metal 0.25 ) instantiates a textured cube.'
    },
    R: {
      label: 'Range variable',
      badge: 'Variable',
      syntax: 'R name ( min max )',
      desc: 'Declares a random procedural variable over a numeric range inside a rule body.',
      detail: 'Keep it inside a rule body, not as a standalone top-level declaration. Use R* when the variable must resolve to an integer.'
    },
    'R*': {
      label: 'Integer range variable',
      badge: 'Variable',
      syntax: 'R* name ( min max )',
      desc: 'Declares an integer-only procedural variable inside a rule body.',
      detail: 'Keep it inside a rule body. Best for repeat counts, indices, and discrete branching logic.'
    }
  };

  const overlay = document.createElement('div');
  overlay.id = 'editorDiagnosticLayer';
  const readout = document.createElement('div');
  readout.className = 'editor-caret-readout';
  readout.innerHTML = '<strong>Ln 1, Col 1</strong><span>No issues</span>';
  codewrap.appendChild(overlay);
  codewrap.appendChild(readout);

  const buttonTips = {
    go: 'Run the current grammar immediately and rebuild the scene.',
    'btn-random': 'Generate a random starter grammar and inject it into the editor.',
    clr: 'Clear the editor and reset the scene.',
    wrapBtn: 'Toggle line wrapping in the grammar editor.',
    exportSTL: 'Export the current scene as STL.',
    orbitToggle: 'Start or stop slow automatic orbit in the scene viewer.',
    openJsonBtn: 'Load a saved local JSON grammar bundle.',
    exportJsonBtn: 'Export the current local save library to JSON.',
    saveBtn: 'Save the current grammar into local browser storage.'
  };

  Object.keys(buttonTips).forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.title = buttonTips[id];
    if (!el.getAttribute('aria-label')) el.setAttribute('aria-label', buttonTips[id]);
  });

  let currentDiagnostics = [];
  let validateTimer = null;
  let measureCache = null;

  function esc(value) {
    return String(value).replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
  }

  function lineColFromOffset(text, offset) {
    const safeText = String(text || '');
    const safeOffset = Math.max(0, Math.min(Number(offset) || 0, safeText.length));
    let line = 1;
    let lastBreak = -1;
    for (let i = 0; i < safeOffset; i += 1) {
      if (safeText.charCodeAt(i) === 10) {
        line += 1;
        lastBreak = i;
      }
    }
    return { line, col: safeOffset - lastBreak };
  }

  function offsetFromLineCol(text, line, col) {
    const safeText = String(text || '');
    const targetLine = Math.max(1, Number(line) || 1);
    const targetCol = Math.max(1, Number(col) || 1);
    let offset = 0;
    let currentLine = 1;
    while (currentLine < targetLine && offset < safeText.length) {
      const nl = safeText.indexOf('\n', offset);
      if (nl === -1) return safeText.length;
      offset = nl + 1;
      currentLine += 1;
    }
    return Math.min(safeText.length, offset + targetCol - 1);
  }

  function getLineText(text, line) {
    const lines = String(text || '').split('\n');
    return lines[Math.max(0, line - 1)] || '';
  }

  function getMetrics() {
    if (measureCache) return measureCache;
    const cs = window.getComputedStyle(src);
    const probe = document.createElement('span');
    probe.textContent = '0000000000';
    probe.style.position = 'absolute';
    probe.style.visibility = 'hidden';
    probe.style.whiteSpace = 'pre';
    probe.style.fontFamily = cs.fontFamily;
    probe.style.fontSize = cs.fontSize;
    probe.style.fontWeight = cs.fontWeight;
    probe.style.letterSpacing = cs.letterSpacing;
    probe.style.lineHeight = cs.lineHeight;
    document.body.appendChild(probe);
    const charWidth = probe.getBoundingClientRect().width / 10 || 8;
    probe.remove();

    measureCache = {
      lineHeight: parseFloat(cs.lineHeight) || 22,
      paddingTop: parseFloat(cs.paddingTop) || 0,
      paddingLeft: parseFloat(cs.paddingLeft) || 0,
      paddingRight: parseFloat(cs.paddingRight) || 0,
      charWidth,
    };
    return measureCache;
  }

  function invalidateMetrics() {
    measureCache = null;
  }

  function normalizeSeverity(value) {
    return value === 'error' ? 'error' : 'warning';
  }

  function dedupeDiagnostics(list) {
    const seen = new Set();
    return list.filter((item) => {
      const key = [item.line, item.col, item.message, item.severity].join('|');
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function smartEditorDiagnostics(text) {
    if (!window.SmartEditor || typeof window.SmartEditor.analyze !== 'function') return [];
    try {
      const analysis = window.SmartEditor.analyze();
      const tokens = Array.isArray(analysis.tokens) ? analysis.tokens : [];
      return (analysis.errors || []).map((entry) => {
        const token = tokens[entry.i] || tokens[Math.max(0, Math.min(tokens.length - 1, entry.i || 0))];
        const lc = lineColFromOffset(text, token?.start || 0);
        return {
          line: lc.line,
          col: lc.col,
          message: entry.msg || 'Grammar issue',
          severity: 'warning',
          source: 'editor',
          snippet: getLineText(text, lc.line)
        };
      });
    } catch (err) {
      return [];
    }
  }

  function parseDiagnostic(text) {
    const trimmed = String(text || '');
    if (!trimmed.trim()) return null;
    if (typeof window.Grammar !== 'function') return null;
    try {
      new window.Grammar(trimmed);
      return null;
    } catch (err) {
      if (!err) return null;
      const rawLine = Number.isFinite(err.line) && err.line > 0 ? err.line : 1;
      const rawCol = Number.isFinite(err.col) ? err.col : 0;
      return {
        line: Math.max(1, rawLine),
        col: Math.max(1, rawCol + 1),
        message: err.message || 'Grammar parse error',
        severity: 'error',
        source: err.name || 'ParseError',
        snippet: err.snippet || getLineText(trimmed, Math.max(1, rawLine))
      };
    }
  }

  function collectDiagnostics() {
    const text = src.value || '';
    const friendly = smartEditorDiagnostics(text);
    const parsed = parseDiagnostic(text);
    const merged = parsed ? [parsed].concat(friendly) : friendly;
    return dedupeDiagnostics(merged).sort((a, b) => {
      const sa = a.severity === 'error' ? 0 : 1;
      const sb = b.severity === 'error' ? 0 : 1;
      if (sa !== sb) return sa - sb;
      if (a.line !== b.line) return a.line - b.line;
      return a.col - b.col;
    });
  }

  function applyGutterState() {
    const gutterEl = document.getElementById('lineGutter');
    if (!gutterEl) return;
    const spans = Array.from(gutterEl.querySelectorAll('span'));
    spans.forEach((span) => {
      span.classList.remove('is-active', 'has-error', 'has-warning');
      span.removeAttribute('title');
    });
    const activeLine = lineColFromOffset(src.value || '', src.selectionStart || 0).line;
    const lineMap = new Map();
    currentDiagnostics.forEach((diag) => {
      const existing = lineMap.get(diag.line) || [];
      existing.push(diag);
      lineMap.set(diag.line, existing);
    });
    spans.forEach((span, index) => {
      const lineNo = index + 1;
      const lineDiags = lineMap.get(lineNo) || [];
      if (lineNo === activeLine) span.classList.add('is-active');
      if (lineDiags.some((entry) => entry.severity === 'error')) span.classList.add('has-error');
      else if (lineDiags.length) span.classList.add('has-warning');
      if (lineDiags.length) {
        span.title = lineDiags.map((entry) => `${entry.severity.toUpperCase()}: ${entry.message}`).join('\n');
      }
    });
  }

  function renderDiagnosticLayer() {
    overlay.innerHTML = '';
    const metrics = getMetrics();
    const highestByLine = new Map();
    currentDiagnostics.forEach((diag) => {
      const existing = highestByLine.get(diag.line);
      if (!existing || (existing.severity !== 'error' && diag.severity === 'error')) {
        highestByLine.set(diag.line, diag);
      }
    });

    highestByLine.forEach((diag, line) => {
      const lineEl = document.createElement('div');
      lineEl.className = `editor-diagnostic-line is-${normalizeSeverity(diag.severity)}`;
      lineEl.style.top = `${metrics.paddingTop + ((line - 1) * metrics.lineHeight) - src.scrollTop}px`;
      lineEl.style.left = `${metrics.paddingLeft - src.scrollLeft}px`;
      lineEl.style.width = `${Math.max(src.scrollWidth, src.clientWidth) - metrics.paddingLeft - metrics.paddingRight}px`;
      lineEl.style.height = `${metrics.lineHeight}px`;
      overlay.appendChild(lineEl);
    });

    currentDiagnostics.slice(0, 30).forEach((diag) => {
      const caret = document.createElement('div');
      caret.className = `editor-diagnostic-caret is-${normalizeSeverity(diag.severity)}`;
      caret.style.top = `${metrics.paddingTop + ((diag.line - 1) * metrics.lineHeight) - src.scrollTop + 3}px`;
      caret.style.left = `${metrics.paddingLeft + ((Math.max(1, diag.col) - 1) * metrics.charWidth) - src.scrollLeft}px`;
      caret.style.height = `${Math.max(12, metrics.lineHeight - 6)}px`;
      overlay.appendChild(caret);
    });

    src.dataset.errorLines = currentDiagnostics.filter((diag) => diag.severity === 'error').map((diag) => diag.line).join(',');
    src.dataset.warningLines = currentDiagnostics.filter((diag) => diag.severity !== 'error').map((diag) => diag.line).join(',');
    applyGutterState();
  }

  function updateReadout() {
    const lc = lineColFromOffset(src.value || '', src.selectionStart || 0);
    const errorCount = currentDiagnostics.filter((diag) => diag.severity === 'error').length;
    const warningCount = currentDiagnostics.filter((diag) => diag.severity !== 'error').length;
    const summary = errorCount ? `${errorCount} error${errorCount === 1 ? '' : 's'}` : warningCount ? `${warningCount} warning${warningCount === 1 ? '' : 's'}` : 'No issues';
    readout.innerHTML = `<strong>Ln ${lc.line}, Col ${lc.col}</strong><span>${summary}</span>`;
    if (statusEl && !statusEl.classList.contains('processing')) {
      const base = errorCount ? `Issues: ${errorCount}${warningCount ? ` + ${warningCount} warnings` : ''}` : warningCount ? `Warnings: ${warningCount}` : 'Ready';
      statusEl.textContent = `${base} · Ln ${lc.line}, Col ${lc.col}`;
      if (errorCount) statusEl.className = 'pill pill-status error';
      else if (warningCount) statusEl.className = 'pill pill-status processing';
      else statusEl.className = 'pill pill-status ready';
    }
  }

  function validateNow() {
    currentDiagnostics = collectDiagnostics();
    renderDiagnosticLayer();
    updateReadout();
    src.dispatchEvent(new CustomEvent('pg3d-diagnostics-change', { bubbles: true, detail: { diagnostics: currentDiagnostics } }));
  }

  function scheduleValidate() {
    if (validateTimer) clearTimeout(validateTimer);
    validateTimer = setTimeout(validateNow, 120);
  }

  function installRichTooltip() {
    if (!tip) return;
    const keywordFromRaw = (raw) => TOOLTIPS[raw] || null;
    const findNearbyDiagnostic = (line, col) => currentDiagnostics.find((diag) => diag.line === line && Math.abs(diag.col - col) <= 2) || currentDiagnostics.find((diag) => diag.line === line);

    codewrap.addEventListener('mousemove', (event) => {
      const span = event.target && event.target.closest ? event.target.closest('#se-hit-pre span') : null;
      if (!span || tip.style.display === 'none') return;

      const raw = span.textContent || '';
      const start = Number(span.dataset.s || 0);
      const lc = lineColFromOffset(src.value || '', start);
      const diag = span.dataset.err ? {
        message: span.dataset.err,
        severity: 'error',
        line: lc.line,
        col: lc.col,
        snippet: getLineText(src.value || '', lc.line)
      } : findNearbyDiagnostic(lc.line, lc.col);

      let model = null;
      const kind = span.dataset.type || 'token';
      if (diag) {
        model = {
          label: diag.severity === 'error' ? 'Grammar error' : 'Grammar warning',
          badge: diag.severity === 'error' ? 'Error' : 'Warning',
          syntax: diag.snippet ? `${diag.snippet}\n${' '.repeat(Math.max(0, diag.col - 1))}^` : `Line ${diag.line}, column ${diag.col}`,
          desc: diag.message,
          detail: `Line ${diag.line}, column ${diag.col}${diag.source ? ` · ${diag.source}` : ''}`,
          state: diag.severity
        };
      } else if (keywordFromRaw(raw)) {
        model = keywordFromRaw(raw);
      } else {
        const baseMeta = `Line ${lc.line}, column ${lc.col}`;
        if (kind === 'num') {
          model = { label: 'Numeric literal', badge: 'Value', syntax: raw, desc: 'Literal number used directly in the grammar.', detail: baseMeta };
        } else if (kind === 'id') {
          const role = span.classList.contains('se-rule-def') ? 'Rule definition' : span.classList.contains('se-rule-ref') ? 'Rule reference' : 'Identifier';
          model = { label: role, badge: 'Symbol', syntax: raw, desc: span.classList.contains('se-unreach') ? 'This rule is currently not reachable from the active start rule.' : 'Identifier or rule symbol in the current grammar.', detail: baseMeta };
        } else if (kind === 'op') {
          model = { label: 'Grammar operator', badge: 'Syntax', syntax: raw, desc: 'Structural token used to separate rule headers, alternates, or blocks.', detail: baseMeta };
        } else if (kind === 'par' || kind === 'br') {
          model = { label: 'Grouping token', badge: 'Syntax', syntax: raw, desc: 'Controls grouped arguments or nested grammar blocks.', detail: baseMeta };
        }
      }

      if (!model) return;
      tip.classList.toggle('is-error', model.state === 'error');
      tip.classList.toggle('is-warning', model.state === 'warning');
      tip.innerHTML = `
        <div class="se-tip">
          <div class="se-tip__head">
            <div class="se-tip__title">
              <div class="se-tip__label">${esc(model.label || raw)}</div>
              <div class="se-tip__meta">${esc((model.detail || `Line ${lc.line}, column ${lc.col}`).trim())}</div>
            </div>
            <span class="se-tip__badge">${esc(model.badge || 'Info')}</span>
          </div>
          <div class="se-tip__body">
            <div class="se-tip__desc">${esc(model.desc || raw)}</div>
            <div class="se-tip__syntax">${esc(model.syntax || raw)}</div>
            ${model.detail && model.detail !== `Line ${lc.line}, column ${lc.col}` ? `<div class="se-tip__detail">${esc(model.detail)}</div>` : ''}
          </div>
        </div>`;
    });
  }

  src.addEventListener('input', scheduleValidate);
  src.addEventListener('scroll', renderDiagnosticLayer, { passive: true });
  src.addEventListener('click', () => { applyGutterState(); updateReadout(); });
  src.addEventListener('keyup', () => { applyGutterState(); updateReadout(); });
  src.addEventListener('mouseup', () => { applyGutterState(); updateReadout(); });
  src.addEventListener('select', () => { applyGutterState(); updateReadout(); });
  src.addEventListener('pg3d-diagnostics-change', applyGutterState);
  src.addEventListener('pg3d-diagnostics-change', updateReadout);
  src.addEventListener('input', () => {
    if (statusEl && statusEl.classList.contains('error')) {
      statusEl.className = 'pill pill-status processing';
      statusEl.textContent = 'Rechecking grammar…';
    }
  });

  const goBtn = document.getElementById('go');
  if (goBtn) goBtn.addEventListener('click', validateNow, true);

  window.addEventListener('resize', () => {
    invalidateMetrics();
    renderDiagnosticLayer();
    updateReadout();
  });

  if ('ResizeObserver' in window) {
    new ResizeObserver(() => {
      invalidateMetrics();
      renderDiagnosticLayer();
      updateReadout();
    }).observe(src);
  }

  installRichTooltip();
  validateNow();
})();
