
(function () {
  "use strict";

  const EXAMPLES = {
    "Load Example…": "",
    "Cube metal": "Start -> I ( Cube metal 0.5 )",
    "CubeX beam": "Start -> S ( 1 1 4 ) I ( CubeX metal 0.4 )",
    "Stacked forms": "Start -> [ I ( Cube stone 0.45 ) ] [ T ( 0 1.2 0 ) S ( 0.7 0.4 0.7 ) I ( Cube glass 0.25 ) ]",
    "Axis deform": "Start -> DSX ( 1.2 1 1 ) DTX ( 0.15 0 0 ) DSY ( 1 0.85 1 ) DTY ( 0 0.2 0 ) DSZ ( 1 1 1.15 ) DTZ ( 0 0 0.18 ) I ( CubeZ metal 0.55 )"
  };

  function $(selector, root) {
    return (root || document).querySelector(selector);
  }

  function make(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  function setLabel(button, label) {
    if (!button) return;
    button.textContent = label;
    button.setAttribute("aria-label", label);
    button.title = label;
  }

  function moveTo(target, nodes) {
    nodes.forEach((node) => {
      if (node && target) target.appendChild(node);
    });
  }

  function buildTopbar() {
    if ($(".match-topbar")) return;

    const appShell = $(".app-shell");
    if (!appShell) return;

    document.body.classList.add("layout-match-active");

    const topbar = make("div", "match-topbar");
    const left = make("div", "match-topbar__left");
    const right = make("div", "match-topbar__right");

    topbar.appendChild(left);
    topbar.appendChild(right);
    document.body.insertBefore(topbar, appShell);

    const runtimeLabel = make("div", "match-runtime-label");
    const runtimeTitle = make("strong", "", "Inline modular editor");
    const runtimeMeta = make("span", "", "Examples, viewer controls, export, and live grammar runtime");
    runtimeLabel.appendChild(runtimeTitle);
    runtimeLabel.appendChild(runtimeMeta);
    left.appendChild(runtimeLabel);

    const wrapBtn = document.getElementById("wrapBtn");
    const openBtn = document.getElementById("openJsonBtn");
    const saveBtn = document.getElementById("saveBtn");
    const utility = make("div", "match-topbar__utility");
    moveTo(utility, [saveBtn, wrapBtn, openBtn]);
    if (utility.children.length) {
      Array.from(utility.children).forEach((btn) => btn.classList.add("match-icon-btn"));
      right.appendChild(utility);
    }
  }

  function buildEditorToolbar() {
    const toolbar = document.getElementById("toolbar");
    if (!toolbar || toolbar.dataset.layoutTarget === "true") return;

    toolbar.classList.add("match-toolbar");

    const actions = make("div", "match-editor-controls");
    const utility = make("div", "match-editor-utility");

    const exampleSelect = make("select", "select-input match-example-select");
    exampleSelect.id = "matchExampleChooser";

    Object.keys(EXAMPLES).forEach((label, i) => {
      const opt = document.createElement("option");
      opt.value = label;
      opt.textContent = label;
      if (i === 0) opt.selected = true;
      exampleSelect.appendChild(opt);
    });

    exampleSelect.addEventListener("change", () => {
      const src = document.getElementById("src");
      const value = EXAMPLES[exampleSelect.value];
      if (!src || !value) return;
      src.value = value;
      src.dispatchEvent(new Event("input", { bubbles: true }));
      src.focus();
    });

    moveTo(actions, [
      document.getElementById("go"),
      document.getElementById("btn-random"),
      document.getElementById("clr")
    ]);

    const nameId = document.getElementById("nameId");
    if (nameId) {
      nameId.placeholder = "save_name";
      utility.appendChild(nameId);
    }

    const nameChooser = document.getElementById("nameChooser");
    if (nameChooser) {
      const placeholder = nameChooser.querySelector('option[value=""]');
      if (placeholder) placeholder.textContent = "Load Saved…";
      utility.appendChild(nameChooser);
    }

    utility.appendChild(exampleSelect);

    toolbar.innerHTML = "";
    toolbar.appendChild(actions);
    toolbar.appendChild(utility);
    toolbar.dataset.layoutTarget = "true";
  }

  function syncOrbitLabel() {
    const orbitToggle = document.getElementById("orbitToggle");
    if (!orbitToggle) return;

    const raw = String(orbitToggle.textContent || "").toLowerCase();
    const isOn = raw.includes("pause") || raw.includes("on");

    orbitToggle.classList.toggle("is-off", !isOn);
    orbitToggle.innerHTML = "";

    const dot = make("span", "match-orbit-dot");
    const label = make("span", "", "Auto Orbit: " + (isOn ? "On" : "Off"));

    orbitToggle.appendChild(dot);
    orbitToggle.appendChild(label);
  }

  function buildViewerToolbar() {
    const viewerToolbar = document.querySelector(".viewer-toolbar");
    if (!viewerToolbar || viewerToolbar.dataset.layoutTarget === "true") return;

    viewerToolbar.classList.add("match-viewer-actions");
    viewerToolbar.innerHTML = "";

    const exportJsonBtn = document.getElementById("exportJsonBtn");
    const exportStlBtn = document.getElementById("exportSTL");
    const fitViewBtn = document.getElementById("fitViewBtn");
    const resetViewBtn = document.getElementById("resetViewBtn");
    const orbitToggle = document.getElementById("orbitToggle");

    if (exportJsonBtn) {
      exportJsonBtn.classList.add("match-softlink");
      setLabel(exportJsonBtn, "JSON");
      viewerToolbar.appendChild(exportJsonBtn);
    }

    if (exportStlBtn) {
      exportStlBtn.classList.add("match-softlink");
      setLabel(exportStlBtn, "STL");
      viewerToolbar.appendChild(exportStlBtn);
    }

    [fitViewBtn, resetViewBtn].forEach((btn) => {
      if (btn) viewerToolbar.appendChild(btn);
    });

    if (orbitToggle) {
      viewerToolbar.appendChild(orbitToggle);
      syncOrbitLabel();
      orbitToggle.addEventListener("click", () => setTimeout(syncOrbitLabel, 0));
    }

    viewerToolbar.dataset.layoutTarget = "true";
  }

  function simplifyTitles() {
    const map = [
      [".input-card h2", "GRAMMAR INPUT"],
      [".viewer-card h2", "SCENE VIEWER"],
      [".output-card h2", "CONSOLE"]
    ];

    map.forEach(([selector, text]) => {
      const node = $(selector);
      if (node) node.textContent = text;
    });
  }

  function installLineGutter() {
    const codewrap = document.getElementById("codewrap");
    const src = document.getElementById("src");
    if (!codewrap || !src || document.getElementById("lineGutter")) return;

    const gutter = make("div", "line-gutter");
    gutter.id = "lineGutter";
    codewrap.insertBefore(gutter, codewrap.firstChild);

    const hint = make("div", "editor-run-hint", "Ctrl+Enter to run");
    codewrap.appendChild(hint);

    const render = () => {
      const count = Math.max(1, String(src.value || "").split("\n").length);
      gutter.innerHTML = "";
      for (let i = 1; i <= count; i += 1) {
        gutter.appendChild(make("span", "", String(i)));
      }
      gutter.scrollTop = src.scrollTop;
    };

    src.addEventListener("input", render);
    src.addEventListener("scroll", () => {
      gutter.scrollTop = src.scrollTop;
    });

    src.addEventListener("keydown", (ev) => {
      if ((ev.ctrlKey || ev.metaKey) && ev.key === "Enter") {
        ev.preventDefault();
        document.getElementById("go")?.click();
      }
    });

    window.addEventListener("resize", render);
    render();
  }

  function init() {
    buildTopbar();
    simplifyTitles();
    buildEditorToolbar();
    buildViewerToolbar();
    installLineGutter();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
