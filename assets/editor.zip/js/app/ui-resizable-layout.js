(function () {
  "use strict";

  const STORAGE_KEY = "progen3d:resizable-layout:v1";
  const MOBILE_BREAKPOINT = 1100;
  const SPLITTER_SIZE = 10;
  const MIN_LEFT = 420;
  const MIN_RIGHT = 320;
  const MIN_VIEWER = 280;
  const MIN_CONSOLE = 150;

  function px(n) {
    return `${Math.round(n)}px`;
  }

  function clamp(n, lo, hi) {
    return Math.max(lo, Math.min(hi, n));
  }

  function $(selector, root) {
    return (root || document).querySelector(selector);
  }

  function loadState() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    } catch (_) {
      return {};
    }
  }

  function saveState(state) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (_) {}
  }

  function getWrapMetrics(wrap) {
    const rect = wrap.getBoundingClientRect();
    const availableHeight = Math.max(520, window.innerHeight - rect.top - 12);
    return {
      width: Math.max(300, wrap.clientWidth),
      height: availableHeight
    };
  }

  function applyWorkspaceHeight(wrap) {
    const rect = wrap.getBoundingClientRect();
    const availableHeight = Math.max(520, window.innerHeight - rect.top - 12);
    wrap.style.setProperty("--match-workspace-h", px(availableHeight));
    return availableHeight;
  }

  function applyState(wrap, state, fromResize) {
    const isMobile = window.innerWidth <= MOBILE_BREAKPOINT;
    wrap.classList.toggle("resizable-layout-mobile", isMobile);

    const metrics = getWrapMetrics(wrap);
    const totalWidth = metrics.width - SPLITTER_SIZE;
    const totalRightHeight = metrics.height - SPLITTER_SIZE;

    if (isMobile) {
      wrap.style.removeProperty("--match-left-pane-w");
      wrap.style.removeProperty("--match-right-pane-w");
      wrap.style.removeProperty("--match-viewer-pane-h");
      wrap.style.removeProperty("--match-console-pane-h");
      return;
    }

    let left = Number(state.leftPx);
    let right = Number(state.rightPx);
    let viewer = Number(state.viewerPx);
    let consoleH = Number(state.consolePx);

    if (!Number.isFinite(left) || !Number.isFinite(right) || left <= 0 || right <= 0 || !fromResize) {
      left = Math.round(totalWidth * 0.64);
      right = totalWidth - left;
    }

    if (!Number.isFinite(viewer) || !Number.isFinite(consoleH) || viewer <= 0 || consoleH <= 0 || !fromResize) {
      viewer = Math.round(totalRightHeight * 0.72);
      consoleH = totalRightHeight - viewer;
    }

    left = clamp(left, MIN_LEFT, totalWidth - MIN_RIGHT);
    right = totalWidth - left;

    viewer = clamp(viewer, MIN_VIEWER, totalRightHeight - MIN_CONSOLE);
    consoleH = totalRightHeight - viewer;

    wrap.style.setProperty("--match-left-pane-w", px(left));
    wrap.style.setProperty("--match-right-pane-w", px(right));
    wrap.style.setProperty("--match-viewer-pane-h", px(viewer));
    wrap.style.setProperty("--match-console-pane-h", px(consoleH));

    state.leftPx = left;
    state.rightPx = right;
    state.viewerPx = viewer;
    state.consolePx = consoleH;
    saveState(state);
  }

  function installSplitters(wrap) {
    const vSplit = $(".layout-splitter-v", wrap);
    const hSplit = $(".layout-splitter-h", wrap);
    if (!vSplit || !hSplit) return;

    const state = loadState();
    applyWorkspaceHeight(wrap);
    applyState(wrap, state, true);

    function beginDrag(kind, ev) {
      if (window.innerWidth <= MOBILE_BREAKPOINT) return;

      ev.preventDefault();
      const startX = ev.clientX;
      const startY = ev.clientY;
      const startState = loadState();
      const metrics = getWrapMetrics(wrap);

      const startLeft = Number(startState.leftPx) || Math.round((metrics.width - SPLITTER_SIZE) * 0.64);
      const startViewer = Number(startState.viewerPx) || Math.round((metrics.height - SPLITTER_SIZE) * 0.72);

      document.body.classList.add("layout-resizing");

      function onMove(moveEv) {
        if (kind === "vertical") {
          const totalWidth = metrics.width - SPLITTER_SIZE;
          const left = clamp(startLeft + (moveEv.clientX - startX), MIN_LEFT, totalWidth - MIN_RIGHT);
          const right = totalWidth - left;
          state.leftPx = left;
          state.rightPx = right;
        } else {
          const totalHeight = metrics.height - SPLITTER_SIZE;
          const viewer = clamp(startViewer + (moveEv.clientY - startY), MIN_VIEWER, totalHeight - MIN_CONSOLE);
          const consoleH = totalHeight - viewer;
          state.viewerPx = viewer;
          state.consolePx = consoleH;
        }

        applyState(wrap, state, true);
        window.dispatchEvent(new Event("resize"));
      }

      function onUp() {
        document.removeEventListener("pointermove", onMove);
        document.removeEventListener("pointerup", onUp);
        document.body.classList.remove("layout-resizing");
      }

      document.addEventListener("pointermove", onMove);
      document.addEventListener("pointerup", onUp, { once: true });
    }

    vSplit.addEventListener("pointerdown", (ev) => beginDrag("vertical", ev));
    hSplit.addEventListener("pointerdown", (ev) => beginDrag("horizontal", ev));

    let resizeTimer = null;
    window.addEventListener("resize", () => {
      applyWorkspaceHeight(wrap);
      if (resizeTimer) clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        const current = loadState();
        applyState(wrap, current, true);
        window.dispatchEvent(new Event("resize"));
      }, 60);
    });
  }

  function triggerInitialFit() {
    let tries = 0;
    const maxTries = 30;

    function attempt() {
      tries += 1;
      const btn = document.getElementById("fitViewBtn");
      if (btn) {
        btn.click();
        return;
      }
      if (tries < maxTries) {
        setTimeout(attempt, 250);
      }
    }

    setTimeout(attempt, 350);
  }

  function init() {
    const wrap = document.querySelector(".wrap");
    if (!wrap) return;
    installSplitters(wrap);
    triggerInitialFit();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();