
// Extracted from original file lines 2583-2621
"use strict";
const log2 = (...a) => {
   
    const msg = `${a.join(" ")}`;
    const out = (typeof document !== "undefined") && document.getElementById && document.getElementById("out");
    if (out){ out.textContent += "\n" + msg; out.scrollTop = out.scrollHeight; }
    else if (typeof console !== "undefined" && console.debug){ console.debug(msg); }
  };





/* ============= Minimal math (column-major) ===================== */
const Mat4 = {
  identity() { return new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]); },
  multiply(a, b) { // c = a * b
    const c = new Float32Array(16);
    for (let col = 0; col < 4; col++) {
      const bi = col * 4;
      const b0 = b[bi + 0], b1 = b[bi + 1], b2 = b[bi + 2], b3 = b[bi + 3];
      c[bi + 0] = a[0] * b0 + a[4] * b1 + a[8]  * b2 + a[12] * b3;
      c[bi + 1] = a[1] * b0 + a[5] * b1 + a[9]  * b2 + a[13] * b3;
      c[bi + 2] = a[2] * b0 + a[6] * b1 + a[10] * b2 + a[14] * b3;
      c[bi + 3] = a[3] * b0 + a[7] * b1 + a[11] * b2 + a[15] * b3;
    }
    return c;
  },
  translation(tx, ty, tz) { const m = Mat4.identity(); m[12]=tx; m[13]=ty; m[14]=tz; return m; },
  scale(sx, sy, sz)       { const m = Mat4.identity(); m[0]=sx; m[5]=sy; m[10]=sz; return m; },
  rotX(rad) { const c=Math.cos(rad), s=Math.sin(rad); return new Float32Array([1,0,0,0, 0,c,s,0, 0,-s,c,0, 0,0,0,1]); },
  rotY(rad) { const c=Math.cos(rad), s=Math.sin(rad); return new Float32Array([ c,0,-s,0, 0,1,0,0, s,0,c,0, 0,0,0,1]); },
  rotZ(rad) { const c=Math.cos(rad), s=Math.sin(rad); return new Float32Array([ c,s,0,0, -s,c,0,0, 0,0,1,0, 0,0,0,1]); }
};

const Vec3 = {
  make(x=0, y=0, z=0) { return { x, y, z }; },
  add(a, b) { return { x: a.x + b.x, y: a.y + b.y, z: a.z + b.z }; },
  mul(a, b) { return { x: a.x * b.x, y: a.y * b.y, z: a.z * b.z }; }
};
