// Extracted from original file lines 3379-3515
            // Axis Scene items
"use strict";

// --- Cube vertices (unit cube centered at origin) ---
const cubeVerts = [
  [-0.5, -0.5, -0.5],
  [ 0.5, -0.5, -0.5],
  [ 0.5,  0.5, -0.5],
  [-0.5,  0.5, -0.5],
  [-0.5, -0.5,  0.5],
  [ 0.5, -0.5,  0.5],
  [ 0.5,  0.5,  0.5],
  [-0.5,  0.5,  0.5],
];

// --- Multiply a point by a column-major 4x4 (v' = M * [x y z 1]^T) ---
function transformPoint(M, v, w = 1) {
  const x = v[0], y = v[1], z = v[2];
  const xp = M[0]*x + M[4]*y + M[8]*z  + M[12]*w;
  const yp = M[1]*x + M[5]*y + M[9]*z  + M[13]*w;
  const zp = M[2]*x + M[6]*y + M[10]*z + M[14]*w;
  const wp = M[3]*x + M[7]*y + M[11]*z + M[15]*w; // stays 1 for affine
  return (wp !== 0 && wp !== 1) ? [xp/wp, yp/wp, zp/wp] : [xp, yp, zp];
}

function axisDeformIdentity() {
  return {
    active: false,
    dsx: [1, 1, 1],
    dsy: [1, 1, 1],
    dsz: [1, 1, 1],
    dtx: [0, 0, 0],
    dty: [0, 0, 0],
    dtz: [0, 0, 0],
  };
}

function applyAffineVec3(scale, translate, point) {
  return [
    scale[0] * point[0] + translate[0],
    scale[1] * point[1] + translate[1],
    scale[2] * point[2] + translate[2],
  ];
}

function cubeTypeConfig(type) {
  if (type === "CubeX") return { Xneg: 0.0,  Xpos: 1.0,  Yneg: -0.5, Ypos: 0.5,  Zneg: -0.5, Zpos: 0.5, axisName: "x" };
  if (type === "CubeY") return { Xneg: -0.5, Xpos: 0.5,  Yneg: 0.0,  Ypos: 1.0,  Zneg: -0.5, Zpos: 0.5, axisName: "y" };
  if (type === "CubeZ") return { Xneg: -0.5, Xpos: 0.5,  Yneg: -0.5, Ypos: 0.5,  Zneg: 0.0,  Zpos: 1.0, axisName: "z" };
  return                    { Xneg: -0.5, Xpos: 0.5,  Yneg: -0.5, Ypos: 0.5,  Zneg: -0.5, Zpos: 0.5, axisName: "z" };
}

function buildAxisDeformedVerts(type, axisDeform) {
  const cfg = cubeTypeConfig(type);
  const spec = Object.assign(axisDeformIdentity(), axisDeform || {});
  const baseVerts = [
    [cfg.Xneg, cfg.Yneg, cfg.Zneg],
    [cfg.Xpos, cfg.Yneg, cfg.Zneg],
    [cfg.Xpos, cfg.Ypos, cfg.Zneg],
    [cfg.Xneg, cfg.Ypos, cfg.Zneg],
    [cfg.Xneg, cfg.Yneg, cfg.Zpos],
    [cfg.Xpos, cfg.Yneg, cfg.Zpos],
    [cfg.Xpos, cfg.Ypos, cfg.Zpos],
    [cfg.Xneg, cfg.Ypos, cfg.Zpos],
  ];

  return baseVerts.map((vert, i) => {
    let p = [vert[0], vert[1], vert[2]];
    const isNegX = (i === 0 || i === 3 || i === 4 || i === 7);
    const isNegY = (i === 0 || i === 1 || i === 4 || i === 5);
    const isNegZ = (i === 0 || i === 1 || i === 2 || i === 3);

    if (isNegX) p = applyAffineVec3(spec.dsx, spec.dtx, p);
    if (isNegY) p = applyAffineVec3(spec.dsy, spec.dty, p);
    if (isNegZ) p = applyAffineVec3(spec.dsz, spec.dtz, p);
    return p;
  });
}

/* ======================= Axis ======================= */
class Axis {
  /**
   * @param {"x"|"y"|"z"} kind
   * x → [[ 0.5, 0,   0],[ -0.5, 0,   0]]
   * y → [[ 0,   0.5, 0],[  0,  -0.5, 0]]
   * z → [[ 0,   0,   0.5],[ 0,   0,  -0.5]]
   */
  constructor(kind = "z") {
    this.kind = (kind === "x" || kind === "y" || kind === "z") ? kind : "z";
    if (this.kind === "x") {
      this.verts = [[ 0.5, 0, 0], [-0.5, 0, 0]];
    } else if (this.kind === "y") {
      this.verts = [[0, 0.5, 0], [0, -0.5, 0]];
    } else {
      this.verts = [[0, 0, 0.5], [0, 0, -0.5]];
    }
  }

  /** Multiply both vertices by a 4x4 column-major matrix */
  applyTransform(M) {
    this.verts = this.verts.map(v => transformPoint(M, v, 1));
    return this;
  }

  toFlat32() {
    return new Float32Array(this.verts.flat());
  }
}

/* ======================= Scene ======================= */
class Scene {
  constructor() { this.items = []; }

  /**
   * Add a cube-like primitive with two/three-stage transform.
   * Also attaches an axis (default "z") transformed by transform1.
   *
   * @param {"Cube"|"CubeX"|"CubeY"|"CubeZ"} type
   * @param {Float32Array|number[]}  transform1
   * @param {Float32Array|number[]}  transform2
   * @param {Float32Array|number[]}  transform3
   * @param {number}                 texIndex
   * @param {number}                 arg
   * @param {number}                 val
   * @param {"x"|"y"|"z"}            axisName  (optional; default "z")
   */
  add(type, transform1, transform2, transform3, texIndex, arg, val, axisName = "z", axisDeform = null) {
    let baseVerts = cubeVerts;

    if (type === "CubeZ" || (axisDeform && axisDeform.active)) {
      const explicitVerts = buildAxisDeformedVerts(type, axisDeform);
      const finalVerts = explicitVerts.map(v => transformPoint(transform1, v));
      const flat = new Float32Array(finalVerts.flat());
      const axisrot = new Axis(cubeTypeConfig(type).axisName).applyTransform(transform1);
      return this.#pushItem(type, transform1, transform2, transform3, finalVerts, flat, texIndex, arg, val, axisrot);

    } else if (type === "Cube") {
      let transformVerts = baseVerts.map(v => (v[2] > 0) ? transformPoint(transform2, v) : v);
      transformVerts = transformVerts.map(v => (v[1] > 0) ? transformPoint(transform3, v) : v);
      const finalVerts = transformVerts.map(v => transformPoint(transform1, v));

      const flat = new Float32Array(finalVerts.flat());
      // Build & transform axis by transform1 before storing
      const axisrot = new Axis("z").applyTransform(transform1);

      return this.#pushItem(type, transform1, transform2, transform3, finalVerts, flat, texIndex, arg, val, axisrot);

    } else if (type === "CubeX") {
      const shiftedVerts = baseVerts.map(([x, y, z]) => [x + 0.5, y, z]);
      const transformVerts = shiftedVerts.map(v => (v[0] > 0.5) ? transformPoint(transform2, v) : v);
      const finalVerts = transformVerts.map(v => transformPoint(transform1, v));

      const flat = new Float32Array(finalVerts.flat());
      const axisrot = new Axis("x").applyTransform(transform1);

      return this.#pushItem(type, transform1, transform2, transform3, finalVerts, flat, texIndex, arg, val, axisrot);

    } else if (type === "CubeY") {
      const shiftedVerts = baseVerts.map(([x, y, z]) => [x, y + 0.5, z]);
      const transformVerts = shiftedVerts.map(v => (v[1] > 0.5) ? transformPoint(transform2, v) : v);
      const finalVerts = transformVerts.map(v => transformPoint(transform1, v));

      const flat = new Float32Array(finalVerts.flat());
      const axisrot = new Axis("y").applyTransform(transform1);

      return this.#pushItem(type, transform1, transform2, transform3, finalVerts, flat, texIndex, arg, val, axisrot);

    } else {
      throw new Error(`Scene.add: unknown type "${type}"`);
    }
  }

  #pushItem(type, transform1, transform2, transform3, verts, flat, texIndex, arg, val, axisrot) {
    const item = {
      type,
      transform1,
      transform2,
      transform3,
      verts,                 // array of 8 [x,y,z]
      flat,                  // Float32Array(24)
      texIndex,
      arg: (Number(arg) || 0) | 0,
      val: Number.isFinite(val) ? Number(val) : 0,
      axisrot: {
        kind: axisrot.kind,
        verts: axisrot.verts,           // [[xtop,ytop,ztop],[xbottom,ybottom,zbottom]]
        flat: axisrot.toFlat32()
      }
    };
    this.items.push(item);
    return item;
  }

  clear() { this.items.length = 0; }
  getAll() { return this.items.slice(); }
}
