// Extracted from original file lines 3517-3685
            /*Scope================================================= */

//                                               Scope Class 
//         (C++ port)
/* ======================================================= */
class Scope {
  constructor(other = null) {
    if (other instanceof Scope) {
      this.position   = Vec3.make(other.position.x, other.position.y, other.position.z);
      this.size       = Vec3.make(other.size.x, other.size.y, other.size.z);
      this.size2      = Vec3.make(other.size2.x, other.size2.y, other.size2.z);
      this.x          = Vec3.make(other.x.x, other.x.y, other.x.z);
      this.y          = Vec3.make(other.y.x, other.y.y, other.y.z);
      this.z          = Vec3.make(other.z.x, other.z.y, other.z.z);
      this.anglex     = other.anglex; 
      this.angley     = other.angley; 
      this.anglez     = other.anglez;
      this.Transform  = new Float32Array(other.Transform);
      this.Transform2 = new Float32Array(other.Transform2);
      this.Transform3 = new Float32Array(other.Transform3);
      this.DSXv       = Vec3.make(other.DSXv.x, other.DSXv.y, other.DSXv.z);
      this.DSYv       = Vec3.make(other.DSYv.x, other.DSYv.y, other.DSYv.z);
      this.DSZv       = Vec3.make(other.DSZv.x, other.DSZv.y, other.DSZv.z);
      this.DTXv       = Vec3.make(other.DTXv.x, other.DTXv.y, other.DTXv.z);
      this.DTYv       = Vec3.make(other.DTYv.x, other.DTYv.y, other.DTYv.z);
      this.DTZv       = Vec3.make(other.DTZv.x, other.DTZv.y, other.DTZv.z);
      this.axisDeformActive = !!other.axisDeformActive;
    } else {
      this.position   = Vec3.make(0, 0, 0);
      this.size       = Vec3.make(1, 1, 1);
      this.size2      = Vec3.make(1, 1, 1);
      this.x          = Vec3.make(1, 0, 0);
      this.y          = Vec3.make(0, 1, 0);
      this.z          = Vec3.make(0, 0, 1);
      this.anglex = 0; this.angley = 0; this.anglez = 0;
      this.Transform  = Mat4.identity();   // primary
      this.Transform2 = Mat4.identity();   // secondary scale
      this.Transform3 = Mat4.identity();   // secondary translate
      this.DSXv       = Vec3.make(1, 1, 1);
      this.DSYv       = Vec3.make(1, 1, 1);
      this.DSZv       = Vec3.make(1, 1, 1);
      this.DTXv       = Vec3.make(0, 0, 0);
      this.DTYv       = Vec3.make(0, 0, 0);
      this.DTZv       = Vec3.make(0, 0, 0);
      this.axisDeformActive = false;
    }
  }

  static #degToRad(deg){ return (deg * Math.PI) / 180.0; }
  static #wrap360(deg){ let d = deg % 360; return d < 0 ? d + 360 : d; }

  /* ----- Primary transforms (accumulate) ----- */
  T(v){
    const M = Mat4.translation(v.x, v.y, v.z);
    this.Transform = Mat4.multiply(this.Transform, M);
    this.position  = Vec3.add(this.position, v);
    return this;
  }
  S(v){
    const M = Mat4.scale(v.x, v.y, v.z);
    this.Transform = Mat4.multiply(this.Transform, M);
    this.size = Vec3.mul(this.size, v);
    return this;
  }

  /* ----- Secondary transforms (accumulate; do not overwrite) ----- */
  DS(v){                // secondary scale
    const M = Mat4.scale(v.x, v.y, v.z);
    this.Transform2 = Mat4.multiply(this.Transform2, M);
    this.size2 = Vec3.mul(this.size2, v);
    return this;
  }
  DT(v){                // secondary translate
    const M = Mat4.translation(v.x, v.y, v.z);
    this.Transform3 = Mat4.multiply(this.Transform3, M);
    return this;
  }

  /* ----- Axis-partitioned deformation transforms (component affine) ----- */
  static #mulVec(a, b){ return Vec3.make(a.x * b.x, a.y * b.y, a.z * b.z); }
  static #addVec(a, b){ return Vec3.make(a.x + b.x, a.y + b.y, a.z + b.z); }

  DSX(v){
    this.axisDeformActive = true;
    this.DSXv = Scope.#mulVec(this.DSXv, v);
    this.DTXv = Scope.#mulVec(this.DTXv, v);
    return this;
  }
  DSY(v){
    this.axisDeformActive = true;
    this.DSYv = Scope.#mulVec(this.DSYv, v);
    this.DTYv = Scope.#mulVec(this.DTYv, v);
    return this;
  }
  DSZ(v){
    this.axisDeformActive = true;
    this.DSZv = Scope.#mulVec(this.DSZv, v);
    this.DTZv = Scope.#mulVec(this.DTZv, v);
    return this;
  }
  DTX(v){
    this.axisDeformActive = true;
    this.DTXv = Scope.#addVec(this.DTXv, v);
    return this;
  }
  DTY(v){
    this.axisDeformActive = true;
    this.DTYv = Scope.#addVec(this.DTYv, v);
    return this;
  }
  DTZ(v){
    this.axisDeformActive = true;
    this.DTZv = Scope.#addVec(this.DTZv, v);
    return this;
  }

  /* ----- Rotations (primary) ----- */
  Rx(angleDeg){
    this.anglex = Scope.#wrap360(angleDeg);
    const r = Scope.#degToRad(this.anglex);
    this.Transform = Mat4.multiply(this.Transform, Mat4.rotX(r));
    const c = Math.cos(r), s = Math.sin(r);
    this.x = Vec3.make(1, 0, 0);
    this.y = Vec3.make(0,  c, s);
    this.z = Vec3.make(0, -s, c);
    return this;
  }
  Ry(angleDeg){
    this.angley = Scope.#wrap360(angleDeg);
    const r = Scope.#degToRad(this.angley);
    this.Transform = Mat4.multiply(this.Transform, Mat4.rotY(r));
    const c = Math.cos(r), s = Math.sin(r);
    this.x = Vec3.make( c, 0, -s);
    this.y = Vec3.make( 0, 1,  0);
    this.z = Vec3.make( s, 0,  c);
    return this;
  }
  Rz(angleDeg){
    this.anglez = Scope.#wrap360(angleDeg);
    const r = Scope.#degToRad(this.anglez);
    this.Transform = Mat4.multiply(this.Transform, Mat4.rotZ(r));
    const c = Math.cos(r), s = Math.sin(r);
    this.x = Vec3.make( c, s, 0);
    this.y = Vec3.make(-s, c, 0);
    this.z = Vec3.make( 0, 0, 1);
    return this;
  }

  /* ----- Accessors / utils ----- */
  apply(M){ this.Transform = Mat4.multiply(this.Transform, M); return this; }
  resetPrimary(){ this.Transform = Mat4.identity(); return this; }
  resetSecondary(){
    this.Transform2 = Mat4.identity();
    this.Transform3 = Mat4.identity();
    this.DSXv = Vec3.make(1, 1, 1);
    this.DSYv = Vec3.make(1, 1, 1);
    this.DSZv = Vec3.make(1, 1, 1);
    this.DTXv = Vec3.make(0, 0, 0);
    this.DTYv = Vec3.make(0, 0, 0);
    this.DTZv = Vec3.make(0, 0, 0);
    this.axisDeformActive = false;
    return this;
  }

  getTransform(){  return this.Transform; }
  getTransform2(){ return this.Transform2; }
  getTransform3(){ return this.Transform3; }
  getAxisDeform(){
    return {
      active: !!this.axisDeformActive,
      dsx: [this.DSXv.x, this.DSXv.y, this.DSXv.z],
      dsy: [this.DSYv.x, this.DSYv.y, this.DSYv.z],
      dsz: [this.DSZv.x, this.DSZv.y, this.DSZv.z],
      dtx: [this.DTXv.x, this.DTXv.y, this.DTXv.z],
      dty: [this.DTYv.x, this.DTYv.y, this.DTYv.z],
      dtz: [this.DTZv.x, this.DTZv.y, this.DTZv.z],
    };
  }

  getPosition(){ return Vec3.make(this.position.x, this.position.y, this.position.z); }
  setPosition(pos){ this.position = Vec3.make(pos.x, pos.y, pos.z); return this.getPosition(); }

  getSize(){  return Vec3.make(this.size.x, this.size.y, this.size.z); }
  getSize2(){ return Vec3.make(this.size2.x, this.size2.y, this.size2.z); }

  clone(){ return new Scope(this); }
}

/* ======================================================= */


//                                        Context Class(scope stack) 


/* ======================================================= */
class Context {
  constructor() { this.stack = [ new Scope() ]; }
  current() { return this.stack[this.stack.length - 1]; }
  getCurrentScope() { return this.current(); }
  push() { this.stack.push(new Scope(this.current())); return this.current(); }
  pop()  { if (this.stack.length > 1) this.stack.pop(); return this.current(); }
  pushScope() { return this.push(); }
  popScope()  { return this.pop(); }
  newScope()  { this.stack.push(new Scope()); return this.current(); } // fresh identity
}



/* ======================================================= */

//                                         Error Functions

/* ======================================================= */


class SolutionError extends Error {
  constructor(message, idx = -1, expr = "") {
    const where = (idx >= 0 && expr)
      ? ` at col ${idx + 1}:\n${expr}\n${" ".repeat(idx)}^`
      : "";
    super(`${message}${where}`); this.name = "SolutionError";
  }
}
class ParseError extends Error {
  constructor(message, line = 0, col = 0, snippet = "") {
    super(message); this.name = "ParseError"; this.line = line; this.col = col; this.snippet = snippet;
  }
}
class RuntimeGrammarError extends Error { constructor(message){ super(message); this.name="RuntimeGrammarError"; } }
const ErrorReporter = {
  caret(line, col) { return `${line}\n${" ".repeat(Math.max(0, col))}^`; },
  fromToken(msg, tok) { return new ParseError(msg, tok.line, tok.col, this.caret(tok.sourceLine, tok.col)); }
};
function errorout(e) {
  const hasConsole = typeof console !== "undefined";
  if (e instanceof ParseError) {
    if (hasConsole && console.warn) console.warn(`[ParseError] ${e.message} (line ${e.line}, col ${e.col})\n${e.snippet}`);
  } else {
    if (hasConsole && console.warn) console.warn(String(e));
  }
}
