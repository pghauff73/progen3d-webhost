// Extracted from original file lines 2381-2461
            // fragment code memory that builds a code repository import and export entire repository
document.getElementById("btn-random").addEventListener("click", () => {

  
 const gen = new RVGG();
 const { program, seed, manifest, score } = gen.generateValid();

 document.getElementById("src").value=program;
});

/* Simple JSON store (replace with your app’s real data model) */
let savedData = {};

/* Save to JSON (from textarea + nameId) */
document.getElementById("saveBtn").addEventListener("click", () => {
  const name = document.getElementById("nameId").value.trim();
  const src = document.getElementById("src").value;
  if (!name) {
    alert("Please enter a unique identifier before saving.");
    return;
  }
  savedData[name] = src;
  document.getElementById("status").textContent = `Saved as "${name}".`;
});

/* Export JSON (download file) */
document.getElementById("exportJsonBtn").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(savedData, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "saved_grammar.json";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
});

/* Open JSON (upload + load) */
document.getElementById("openJsonBtn").addEventListener("click", () => {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = "application/json";
  input.onchange = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = evt => {
      try {
        savedData = JSON.parse(evt.target.result);
        document.getElementById("status").textContent = `Loaded ${Object.keys(savedData).length} entries.`;

        // populate dropdown
        const chooser = document.getElementById("nameChooser");
        chooser.innerHTML = '<option value="" disabled selected>Choose saved…</option>';
        Object.keys(savedData).forEach(key => {
          const opt = document.createElement("option");
          opt.value = key;
          opt.textContent = key;
          chooser.appendChild(opt);
        });

      } catch (err) {
        alert("Invalid JSON file.");
      }
    };
    reader.readAsText(file);
  };
  input.click();
});

/* Load from dropdown */
document.getElementById("nameChooser").addEventListener("change", e => {
  const key = e.target.value;
  if (savedData[key]) {
    document.getElementById("src").value = savedData[key];
    document.getElementById("status").textContent = `Loaded "${key}".`;
  }
});
