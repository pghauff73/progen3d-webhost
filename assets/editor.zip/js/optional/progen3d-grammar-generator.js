// Extracted from original file lines 5973-6864
            /**
 * ProGen3D Grammar Generator
 * A comprehensive system for generating procedural content using formal grammars
 * Based on L-Systems, Shape Grammars, and Context-Free Grammars
 */

class ProGen3DGrammar {
    constructor(config = {}) {
        this.axiom = config.axiom || 'A';
        this.rules = config.rules || {};
        this.iterations = config.iterations || 3;
        this.angle = config.angle || 25;
        this.constants = config.constants || {};
        this.stochastic = config.stochastic || false;
        this.contextSensitive = config.contextSensitive || false;
        this.parametric = config.parametric || false;
        this.history = [];
    }

    /**
     * Generate string based on grammar rules
     * @param {number} iterations - Number of iterations to perform
     * @returns {string} Generated string
     */
    generate(iterations = this.iterations) {
        let current = this.axiom;
        this.history = [current];

        for (let i = 0; i < iterations; i++) {
            current = this.applyRules(current);
            this.history.push(current);
        }

        return current;
    }

    /**
     * Apply production rules to current string
     * @param {string} input - Current string
     * @returns {string} Transformed string
     */
    applyRules(input) {
        let output = '';

        for (let i = 0; i < input.length; i++) {
            const symbol = input[i];
            const context = this.getContext(input, i);
            
            if (this.contextSensitive) {
                output += this.applyContextSensitiveRule(symbol, context);
            } else if (this.stochastic) {
                output += this.applyStochasticRule(symbol);
            } else if (this.parametric) {
                output += this.applyParametricRule(symbol, context);
            } else {
                output += this.applySimpleRule(symbol);
            }
        }

        return output;
    }

    /**
     * Apply simple production rule
     */
    applySimpleRule(symbol) {
        return this.rules[symbol] || symbol;
    }

    /**
     * Apply stochastic (probabilistic) rule
     */
    applyStochasticRule(symbol) {
        const rule = this.rules[symbol];
        
        if (!rule) return symbol;
        
        if (Array.isArray(rule)) {
            // Multiple options with probabilities
            const rand = Math.random();
            let cumulative = 0;
            
            for (const option of rule) {
                cumulative += option.probability || (1 / rule.length);
                if (rand <= cumulative) {
                    return option.production || option;
                }
            }
        }
        
        return rule;
    }

    /**
     * Apply context-sensitive rule
     */
    applyContextSensitiveRule(symbol, context) {
        const rule = this.rules[symbol];
        
        if (!rule) return symbol;
        
        if (typeof rule === 'object' && rule.context) {
            const { left, right } = context;
            
            for (const contextRule of rule.context) {
                if (this.matchContext(contextRule, left, right)) {
                    return contextRule.production;
                }
            }
            
            return rule.default || symbol;
        }
        
        return rule;
    }

    /**
     * Apply parametric rule with parameters
     */
    applyParametricRule(symbol, context) {
        const rule = this.rules[symbol];
        
        if (!rule) return symbol;
        
        if (typeof rule === 'function') {
            return rule(context, this.constants);
        }
        
        return rule;
    }

    /**
     * Get context around a symbol
     */
    getContext(string, index) {
        return {
            left: string[index - 1] || '',
            right: string[index + 1] || '',
            position: index,
            length: string.length
        };
    }

    /**
     * Match context pattern
     */
    matchContext(contextRule, left, right) {
        const leftMatch = !contextRule.left || contextRule.left === left;
        const rightMatch = !contextRule.right || contextRule.right === right;
        return leftMatch && rightMatch;
    }

    /**
     * Interpret generated string as 3D commands
     */
    interpret(string, options = {}) {
        const commands = [];
        const stack = [];
        let position = { x: 0, y: 0, z: 0 };
        let direction = { x: 0, y: 1, z: 0 };
        let angle = options.angle || this.angle;

        for (const symbol of string) {
            switch (symbol) {
                case 'F': // Move forward and draw
                    const newPos = {
                        x: position.x + direction.x,
                        y: position.y + direction.y,
                        z: position.z + direction.z
                    };
                    commands.push({
                        type: 'line',
                        from: { ...position },
                        to: newPos
                    });
                    position = newPos;
                    break;

                case 'f': // Move forward without drawing
                    position.x += direction.x;
                    position.y += direction.y;
                    position.z += direction.z;
                    break;

                case '+': // Rotate right
                    direction = this.rotate2D(direction, angle);
                    break;

                case '-': // Rotate left
                    direction = this.rotate2D(direction, -angle);
                    break;

                case '&': // Pitch down
                    direction = this.pitchDown(direction, angle);
                    break;

                case '^': // Pitch up
                    direction = this.pitchUp(direction, angle);
                    break;

                case '\\': // Roll left
                    direction = this.rollLeft(direction, angle);
                    break;

                case '/': // Roll right
                    direction = this.rollRight(direction, angle);
                    break;

                case '|': // Turn around
                    direction.x = -direction.x;
                    direction.y = -direction.y;
                    direction.z = -direction.z;
                    break;

                case '[': // Push state
                    stack.push({
                        position: { ...position },
                        direction: { ...direction }
                    });
                    break;

                case ']': // Pop state
                    const state = stack.pop();
                    if (state) {
                        position = state.position;
                        direction = state.direction;
                    }
                    break;

                case '{': // Start polygon
                    commands.push({ type: 'startPolygon' });
                    break;

                case '}': // End polygon
                    commands.push({ type: 'endPolygon' });
                    break;

                case '.': // Add vertex
                    commands.push({
                        type: 'vertex',
                        position: { ...position }
                    });
                    break;

                default:
                    // Ignore other symbols
                    break;
            }
        }

        return commands;
    }

    /**
     * Rotate direction in 2D plane
     */
    rotate2D(dir, angle) {
        const rad = (angle * Math.PI) / 180;
        const cos = Math.cos(rad);
        const sin = Math.sin(rad);
        
        return {
            x: dir.x * cos - dir.y * sin,
            y: dir.x * sin + dir.y * cos,
            z: dir.z
        };
    }

    /**
     * Pitch down (rotate around X axis)
     */
    pitchDown(dir, angle) {
        const rad = (angle * Math.PI) / 180;
        const cos = Math.cos(rad);
        const sin = Math.sin(rad);
        
        return {
            x: dir.x,
            y: dir.y * cos - dir.z * sin,
            z: dir.y * sin + dir.z * cos
        };
    }

    /**
     * Pitch up (rotate around X axis, opposite direction)
     */
    pitchUp(dir, angle) {
        return this.pitchDown(dir, -angle);
    }

    /**
     * Roll left (rotate around Y axis)
     */
    rollLeft(dir, angle) {
        const rad = (angle * Math.PI) / 180;
        const cos = Math.cos(rad);
        const sin = Math.sin(rad);
        
        return {
            x: dir.x * cos + dir.z * sin,
            y: dir.y,
            z: -dir.x * sin + dir.z * cos
        };
    }

    /**
     * Roll right (rotate around Y axis, opposite direction)
     */
    rollRight(dir, angle) {
        return this.rollLeft(dir, -angle);
    }

    /**
     * Export grammar definition
     */
    export() {
        return {
            axiom: this.axiom,
            rules: this.rules,
            iterations: this.iterations,
            angle: this.angle,
            constants: this.constants,
            stochastic: this.stochastic,
            contextSensitive: this.contextSensitive,
            parametric: this.parametric
        };
    }

    /**
     * Import grammar definition
     */
    import(definition) {
        Object.assign(this, definition);
        return this;
    }
}

/**
 * Predefined Grammar Library
 */
class GrammarLibrary {
    static get TREE_SIMPLE() {
        return {
            axiom: 'F',
            rules: {
                'F': 'F[+F]F[-F]F'
            },
            iterations: 4,
            angle: 25.7
        };
    }

    static get TREE_COMPLEX() {
        return {
            axiom: 'X',
            rules: {
                'X': 'F[+X][-X]FX',
                'F': 'FF'
            },
            iterations: 5,
            angle: 25
        };
    }

    static get BUSH() {
        return {
            axiom: 'F',
            rules: {
                'F': 'FF+[+F-F-F]-[-F+F+F]'
            },
            iterations: 4,
            angle: 22.5
        };
    }

    static get ALGAE() {
        return {
            axiom: 'A',
            rules: {
                'A': 'AB',
                'B': 'A'
            },
            iterations: 7,
            angle: 0
        };
    }

    static get KOCH_CURVE() {
        return {
            axiom: 'F',
            rules: {
                'F': 'F+F-F-F+F'
            },
            iterations: 4,
            angle: 90
        };
    }

    static get SIERPINSKI_TRIANGLE() {
        return {
            axiom: 'F-G-G',
            rules: {
                'F': 'F-G+F+G-F',
                'G': 'GG'
            },
            iterations: 6,
            angle: 120
        };
    }

    static get DRAGON_CURVE() {
        return {
            axiom: 'FX',
            rules: {
                'X': 'X+YF+',
                'Y': '-FX-Y'
            },
            iterations: 10,
            angle: 90
        };
    }

    static get HILBERT_CURVE() {
        return {
            axiom: 'A',
            rules: {
                'A': '-BF+AFA+FB-',
                'B': '+AF-BFB-FA+'
            },
            iterations: 5,
            angle: 90
        };
    }

    static get PLANT_3D() {
        return {
            axiom: 'A',
            rules: {
                'A': '[&FL!A]/////[&FL!A]///////[&FL!A]',
                'F': 'S/////F',
                'S': 'FL',
                'L': '[^^^{-f+f+f-|-f+f+f}]'
            },
            iterations: 8,
            angle: 22.5
        };
    }

    static get STOCHASTIC_TREE() {
        return {
            axiom: 'F',
            rules: {
                'F': [
                    { production: 'F[+F]F[-F]F', probability: 0.33 },
                    { production: 'F[+F]F', probability: 0.33 },
                    { production: 'F[-F]F', probability: 0.34 }
                ]
            },
            iterations: 4,
            angle: 25,
            stochastic: true
        };
    }

    static get CONTEXT_SENSITIVE_GROWTH() {
        return {
            axiom: 'BAAAA',
            rules: {
                'A': {
                    context: [
                        { left: 'B', right: 'A', production: 'B' },
                        { left: 'A', right: 'A', production: 'A' }
                    ],
                    default: 'A'
                },
                'B': 'A'
            },
            iterations: 10,
            angle: 0,
            contextSensitive: true
        };
    }

    static get PARAMETRIC_BRANCH() {
        return {
            axiom: 'A(1,10)',
            rules: {
                'A': (context, constants) => {
                    const match = context.left.match(/A\((\d+),(\d+)\)/);
                    if (match) {
                        const l = parseInt(match[1]);
                        const w = parseInt(match[2]);
                        if (w > 1) {
                            return `F(${l})[+A(${l * 0.7},${w * 0.7})][-A(${l * 0.7},${w * 0.7})]A(${l * 0.9},${w * 0.9})`;
                        }
                    }
                    return 'F(1)';
                }
            },
            iterations: 5,
            angle: 30,
            parametric: true
        };
    }
}

/**
 * Shape Grammar Generator
 * For architectural and geometric procedural generation
 */
class ShapeGrammar {
    constructor() {
        this.shapes = [];
        this.rules = [];
    }

    /**
     * Add a shape to the grammar
     */
    addShape(shape) {
        this.shapes.push(shape);
        return this;
    }

    /**
     * Add a production rule
     */
    addRule(pattern, replacement) {
        this.rules.push({ pattern, replacement });
        return this;
    }

    /**
     * Apply rules to generate new shapes
     */
    generate(iterations = 1) {
        let currentShapes = [...this.shapes];

        for (let i = 0; i < iterations; i++) {
            const newShapes = [];

            for (const shape of currentShapes) {
                let replaced = false;

                for (const rule of this.rules) {
                    if (this.matchPattern(shape, rule.pattern)) {
                        newShapes.push(...this.applyReplacement(shape, rule.replacement));
                        replaced = true;
                        break;
                    }
                }

                if (!replaced) {
                    newShapes.push(shape);
                }
            }

            currentShapes = newShapes;
        }

        return currentShapes;
    }

    /**
     * Check if shape matches pattern
     */
    matchPattern(shape, pattern) {
        if (typeof pattern === 'function') {
            return pattern(shape);
        }

        return shape.type === pattern.type;
    }

    /**
     * Apply replacement rule
     */
    applyReplacement(shape, replacement) {
        if (typeof replacement === 'function') {
            return replacement(shape);
        }

        return [replacement];
    }

    /**
     * Building generation example
     */
    static createBuildingGrammar() {
        const grammar = new ShapeGrammar();

        // Initial shape: ground floor
        grammar.addShape({
            type: 'floor',
            level: 0,
            width: 20,
            depth: 20,
            height: 4
        });

        // Rule: Add floors
        grammar.addRule(
            shape => shape.type === 'floor' && shape.level < 10,
            shape => [
                shape,
                {
                    type: 'floor',
                    level: shape.level + 1,
                    width: shape.width * 0.95,
                    depth: shape.depth * 0.95,
                    height: 3
                }
            ]
        );

        // Rule: Add windows
        grammar.addRule(
            shape => shape.type === 'floor',
            shape => [
                shape,
                {
                    type: 'windows',
                    level: shape.level,
                    count: Math.floor(shape.width / 2)
                }
            ]
        );

        return grammar;
    }
}

/**
 * Grammar Visualizer
 * Converts grammar output to visual representation
 */
class GrammarVisualizer {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.scale = 1;
        this.offset = { x: 0, y: 0 };
    }

    /**
     * Draw commands from grammar interpretation
     */
    draw(commands, options = {}) {
        const {
            lineWidth = 1,
            strokeStyle = '#000000',
            fillStyle = '#00ff00',
            scale = 10,
            centerX = this.canvas.width / 2,
            centerY = this.canvas.height / 2
        } = options;

        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.ctx.lineWidth = lineWidth;
        this.ctx.strokeStyle = strokeStyle;
        this.ctx.fillStyle = fillStyle;

        let polygonVertices = [];
        let inPolygon = false;

        for (const command of commands) {
            switch (command.type) {
                case 'line':
                    this.ctx.beginPath();
                    this.ctx.moveTo(
                        centerX + command.from.x * scale,
                        centerY - command.from.y * scale
                    );
                    this.ctx.lineTo(
                        centerX + command.to.x * scale,
                        centerY - command.to.y * scale
                    );
                    this.ctx.stroke();
                    break;

                case 'startPolygon':
                    inPolygon = true;
                    polygonVertices = [];
                    break;

                case 'vertex':
                    if (inPolygon) {
                        polygonVertices.push({
                            x: centerX + command.position.x * scale,
                            y: centerY - command.position.y * scale
                        });
                    }
                    break;

                case 'endPolygon':
                    if (polygonVertices.length > 0) {
                        this.ctx.beginPath();
                        this.ctx.moveTo(polygonVertices[0].x, polygonVertices[0].y);
                        for (let i = 1; i < polygonVertices.length; i++) {
                            this.ctx.lineTo(polygonVertices[i].x, polygonVertices[i].y);
                        }
                        this.ctx.closePath();
                        this.ctx.fill();
                        this.ctx.stroke();
                    }
                    inPolygon = false;
                    polygonVertices = [];
                    break;
            }
        }
    }

    /**
     * Draw 3D projection
     */
    draw3D(commands, options = {}) {
        const {
            scale = 10,
            rotationX = 0,
            rotationY = 0,
            rotationZ = 0
        } = options;

        // Project 3D points to 2D
        const projected = commands.map(cmd => {
            if (cmd.type === 'line') {
                return {
                    type: 'line',
                    from: this.project3D(cmd.from, rotationX, rotationY, rotationZ),
                    to: this.project3D(cmd.to, rotationX, rotationY, rotationZ)
                };
            }
            return cmd;
        });

        this.draw(projected, { ...options, scale });
    }

    /**
     * Project 3D point to 2D
     */
    project3D(point, rotX, rotY, rotZ) {
        // Apply rotations
        let { x, y, z } = point;

        // Rotate around X axis
        const cosX = Math.cos(rotX);
        const sinX = Math.sin(rotX);
        let y1 = y * cosX - z * sinX;
        let z1 = y * sinX + z * cosX;

        // Rotate around Y axis
        const cosY = Math.cos(rotY);
        const sinY = Math.sin(rotY);
        let x1 = x * cosY + z1 * sinY;
        let z2 = -x * sinY + z1 * cosY;

        // Rotate around Z axis
        const cosZ = Math.cos(rotZ);
        const sinZ = Math.sin(rotZ);
        let x2 = x1 * cosZ - y1 * sinZ;
        let y2 = x1 * sinZ + y1 * cosZ;

        // Perspective projection
        const distance = 5;
        const factor = distance / (distance + z2);

        return {
            x: x2 * factor,
            y: y2 * factor,
            z: z2
        };
    }
}

/**
 * Grammar Analyzer
 * Analyze and optimize grammars
 */
class GrammarAnalyzer {
    /**
     * Analyze grammar complexity
     */
    static analyzeComplexity(grammar) {
        const generated = grammar.generate();
        
        return {
            length: generated.length,
            uniqueSymbols: new Set(generated).size,
            depth: grammar.iterations,
            branchingFactor: this.calculateBranchingFactor(grammar),
            growthRate: generated.length / grammar.axiom.length
        };
    }

    /**
     * Calculate branching factor
     */
    static calculateBranchingFactor(grammar) {
        let totalBranches = 0;
        let branchSymbols = 0;

        for (const [symbol, rule] of Object.entries(grammar.rules)) {
            if (typeof rule === 'string') {
                const branches = (rule.match(/\[/g) || []).length;
                if (branches > 0) {
                    totalBranches += branches;
                    branchSymbols++;
                }
            }
        }

        return branchSymbols > 0 ? totalBranches / branchSymbols : 0;
    }

    /**
     * Detect infinite loops
     */
    static detectInfiniteLoops(grammar) {
        const visited = new Set();
        
        function checkSymbol(symbol, path = []) {
            if (path.includes(symbol)) {
                return true; // Cycle detected
            }

            const rule = grammar.rules[symbol];
            if (!rule || typeof rule !== 'string') {
                return false;
            }

            for (const char of rule) {
                if (grammar.rules[char]) {
                    if (checkSymbol(char, [...path, symbol])) {
                        return true;
                    }
                }
            }

            return false;
        }

        return checkSymbol(grammar.axiom);
    }

    /**
     * Suggest optimizations
     */
    static suggestOptimizations(grammar) {
        const suggestions = [];
        const complexity = this.analyzeComplexity(grammar);

        if (complexity.length > 10000) {
            suggestions.push({
                type: 'warning',
                message: 'Generated string is very long. Consider reducing iterations.',
                severity: 'high'
            });
        }

        if (complexity.branchingFactor > 5) {
            suggestions.push({
                type: 'info',
                message: 'High branching factor detected. This may cause exponential growth.',
                severity: 'medium'
            });
        }

        if (this.detectInfiniteLoops(grammar)) {
            suggestions.push({
                type: 'error',
                message: 'Potential infinite loop detected in grammar rules.',
                severity: 'critical'
            });
        }

        return suggestions;
    }
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        ProGen3DGrammar,
        GrammarLibrary,
        ShapeGrammar,
        GrammarVisualizer,
        GrammarAnalyzer
    };
}
