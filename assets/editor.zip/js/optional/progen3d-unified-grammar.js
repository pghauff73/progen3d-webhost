// Extracted from original file lines 6866-8473
            /**
 * ProGen3D Unified Grammar Generator
 * Combines L-Systems, Shape Grammars, and RVGG procedural generation
 * Based on ProGen3D.com grammar syntax research
 */

/* ================= TEXTURE PRESETS ================= */
const TEXTURE_PRESETS = [
  "roughConcrete","smoothConcrete","crackedAsphalt","redBrickWall","whiteTiles","blueCeramicTile",
  "shinySteel","brushedAluminum","oxidizedCopper","agedBronze","shinyGold","tarnishedSilver","rawIron","polishedTitanium",
  "clearGlass","frostedGlass","tintedGreenGlass","stainedBlueGlass",
  "glossyWhitePlastic","matteBlackPlastic","redABS","bluePVC","translucentPoly",
  "freshGrass","dryGrass","desertSand","muddySoil","grayStone","darkBasalt","whiteMarble","greenMarble",
  "oakPlanks","darkWalnut","pineWood","mahoganyWood","cherryWood","mapleWood",
  "iceBlock","moltenLava","deepWater","snowPowder","fluffyCloud","mossPatch","claySoil","rustyMetal",
  "carbonFiber","circuitBoard","glowingPanel","hazardStripe","steelGrid","chromeSurface"
];

/* ================= CORE L-SYSTEM GRAMMAR ENGINE ================= */
class ProGen3DGrammar {
  constructor(config = {}) {
    this.axiom = config.axiom || 'A';
    this.rules = config.rules || {};
    this.iterations = config.iterations || 3;
    this.angle = config.angle || 25;
    this.constants = config.constants || {};
    this.stochastic = config.stochastic || false;
    this.contextSensitive = config.contextSensitive || false;
    this.parametric = config.parametric || false;
    this.history = [];
    this.seed = config.seed || Date.now();
    this.rng = this._makeRng(this.seed);
  }

  /* ---------- RNG utilities ---------- */
  _makeRng(seed = 0x9e3779b1) {
    let s = (seed >>> 0) || 0x9e3779b1;
    return () => {
      s ^= s << 13;
      s ^= s >>> 17;
      s ^= s << 5;
      return ((s >>> 0) / 0xFFFFFFFF);
    };
  }

  _chance(p) { return this.rng() < p; }
  _pick(arr) { return arr[Math.floor(this.rng() * arr.length)]; }
  _range(a, b) { return a + (b - a) * this.rng(); }
  _irange(a, b) { return Math.floor(this._range(a, b + 1)); }

  /* ---------- Grammar Generation ---------- */
  generate(iterations = this.iterations) {
    let current = this.axiom;
    this.history = [current];

    for (let i = 0; i < iterations; i++) {
      current = this.applyRules(current);
      this.history.push(current);
    }

    return current;
  }

  applyRules(input) {
    let output = '';

    for (let i = 0; i < input.length; i++) {
      const symbol = input[i];
      const context = this.getContext(input, i);
      
      if (this.contextSensitive) {
        output += this.applyContextSensitiveRule(symbol, context);
      } else if (this.stochastic) {
        output += this.applyStochasticRule(symbol);
      } else if (this.parametric) {
        output += this.applyParametricRule(symbol, context);
      } else {
        output += this.applySimpleRule(symbol);
      }
    }

    return output;
  }

  applySimpleRule(symbol) {
    return this.rules[symbol] || symbol;
  }

  applyStochasticRule(symbol) {
    const rule = this.rules[symbol];
    
    if (!rule) return symbol;
    
    if (Array.isArray(rule)) {
      const rand = this.rng();
      let cumulative = 0;
      
      for (const option of rule) {
        cumulative += option.probability || (1 / rule.length);
        if (rand <= cumulative) {
          return option.production || option;
        }
      }
    }
    
    return rule;
  }

  applyContextSensitiveRule(symbol, context) {
    const rule = this.rules[symbol];
    
    if (!rule) return symbol;
    
    if (typeof rule === 'object' && rule.context) {
      const { left, right } = context;
      
      for (const contextRule of rule.context) {
        if (this.matchContext(contextRule, left, right)) {
          return contextRule.production;
        }
      }
      
      return rule.default || symbol;
    }
    
    return rule;
  }

  applyParametricRule(symbol, context) {
    const rule = this.rules[symbol];
    
    if (!rule) return symbol;
    
    if (typeof rule === 'function') {
      return rule(context, this.constants);
    }
    
    return rule;
  }

  getContext(string, index) {
    return {
      left: string[index - 1] || '',
      right: string[index + 1] || '',
      position: index,
      length: string.length
    };
  }

  matchContext(contextRule, left, right) {
    const leftMatch = !contextRule.left || contextRule.left === left;
    const rightMatch = !contextRule.right || contextRule.right === right;
    return leftMatch && rightMatch;
  }

  /* ---------- 3D Interpretation ---------- */
  interpret(string, options = {}) {
    const commands = [];
    const stack = [];
    let position = { x: 0, y: 0, z: 0 };
    let direction = { x: 0, y: 1, z: 0 };
    let angle = options.angle || this.angle;

    for (const symbol of string) {
      switch (symbol) {
        case 'F': // Move forward and draw
          const newPos = {
            x: position.x + direction.x,
            y: position.y + direction.y,
            z: position.z + direction.z
          };
          commands.push({
            type: 'line',
            from: { ...position },
            to: newPos
          });
          position = newPos;
          break;

        case 'f': // Move forward without drawing
          position.x += direction.x;
          position.y += direction.y;
          position.z += direction.z;
          break;

        case '+': // Rotate right
          direction = this.rotate2D(direction, angle);
          break;

        case '-': // Rotate left
          direction = this.rotate2D(direction, -angle);
          break;

        case '&': // Pitch down
          direction = this.pitchDown(direction, angle);
          break;

        case '^': // Pitch up
          direction = this.pitchUp(direction, angle);
          break;

        case '\\': // Roll left
          direction = this.rollLeft(direction, angle);
          break;

        case '/': // Roll right
          direction = this.rollRight(direction, angle);
          break;

        case '|': // Turn around
          direction.x = -direction.x;
          direction.y = -direction.y;
          direction.z = -direction.z;
          break;

        case '[': // Push state
          stack.push({
            position: { ...position },
            direction: { ...direction }
          });
          break;

        case ']': // Pop state
          const state = stack.pop();
          if (state) {
            position = state.position;
            direction = state.direction;
          }
          break;

        case '{': // Start polygon
          commands.push({ type: 'startPolygon' });
          break;

        case '}': // End polygon
          commands.push({ type: 'endPolygon' });
          break;

        case '.': // Add vertex
          commands.push({
            type: 'vertex',
            position: { ...position }
          });
          break;
      }
    }

    return commands;
  }

  /* ---------- 3D Rotation Utilities ---------- */
  rotate2D(dir, angle) {
    const rad = (angle * Math.PI) / 180;
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);
    
    return {
      x: dir.x * cos - dir.y * sin,
      y: dir.x * sin + dir.y * cos,
      z: dir.z
    };
  }

  pitchDown(dir, angle) {
    const rad = (angle * Math.PI) / 180;
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);
    
    return {
      x: dir.x,
      y: dir.y * cos - dir.z * sin,
      z: dir.y * sin + dir.z * cos
    };
  }

  pitchUp(dir, angle) {
    return this.pitchDown(dir, -angle);
  }

  rollLeft(dir, angle) {
    const rad = (angle * Math.PI) / 180;
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);
    
    return {
      x: dir.x * cos + dir.z * sin,
      y: dir.y,
      z: -dir.x * sin + dir.z * cos
    };
  }

  rollRight(dir, angle) {
    return this.rollLeft(dir, -angle);
  }

  /* ---------- Export/Import ---------- */
  export() {
    return {
      axiom: this.axiom,
      rules: this.rules,
      iterations: this.iterations,
      angle: this.angle,
      constants: this.constants,
      stochastic: this.stochastic,
      contextSensitive: this.contextSensitive,
      parametric: this.parametric,
      seed: this.seed
    };
  }

  import(definition) {
    Object.assign(this, definition);
    if (definition.seed) {
      this.rng = this._makeRng(definition.seed);
    }
    return this;
  }
}

/* ================= GRAMMAR LIBRARY ================= */
class GrammarLibrary {
  static get TREE_SIMPLE() {
    return {
      axiom: 'F',
      rules: { 'F': 'F[+F]F[-F]F' },
      iterations: 4,
      angle: 25.7
    };
  }

  static get TREE_COMPLEX() {
    return {
      axiom: 'X',
      rules: { 'X': 'F[+X][-X]FX', 'F': 'FF' },
      iterations: 5,
      angle: 25
    };
  }

  static get BUSH() {
    return {
      axiom: 'F',
      rules: { 'F': 'FF+[+F-F-F]-[-F+F+F]' },
      iterations: 4,
      angle: 22.5
    };
  }

  static get PLANT_3D() {
    return {
      axiom: 'A',
      rules: {
        'A': '[&FL!A]/////[&FL!A]///////[&FL!A]',
        'F': 'S/////F',
        'S': 'FL',
        'L': '[^^^{-f+f+f-|-f+f+f}]'
      },
      iterations: 8,
      angle: 22.5
    };
  }

  static get STOCHASTIC_TREE() {
    return {
      axiom: 'F',
      rules: {
        'F': [
          { production: 'F[+F]F[-F]F', probability: 0.33 },
          { production: 'F[+F]F', probability: 0.33 },
          { production: 'F[-F]F', probability: 0.34 }
        ]
      },
      iterations: 4,
      angle: 25,
      stochastic: true
    };
  }

  static get DRAGON_CURVE() {
    return {
      axiom: 'FX',
      rules: { 'X': 'X+YF+', 'Y': '-FX-Y' },
      iterations: 10,
      angle: 90
    };
  }

  static get HILBERT_CURVE() {
    return {
      axiom: 'A',
      rules: { 'A': '-BF+AFA+FB-', 'B': '+AF-BFB-FA+' },
      iterations: 5,
      angle: 90
    };
  }
}

/* ================= RVGG - Random Volumetric Geometry Generator ================= */
class RVGG {
  static DEFAULTS = {
    // motif likelihoods
    pRadial: .7, pStack: .7, pBand: .4, pMirror: .4, pDihedral: .45,
    pSpiral: .45, pGrid: .45, pRandomWalk: .35, pFork: .35, pRingStack: .45,
    pLSystem: .3, // NEW: L-System integration
    // ranges
    spokesMin: 10, spokesMax: 15,
    stacksMin: 4, stacksMax: 12,
    bandSegMin: 8, bandSegMax: 16,
    spiralSegMin: 12, spiralSegMax: 24,
    gridNMin: 3, gridNMax: 7,
    forkDepthMin: 3, forkDepthMax: 5,
    ringNMin: 8, ringNMax: 16,
    ringLayersMin: 2, ringLayersMax: 6,
    // transforms
    scaleMin: .12, scaleMax: 3.5,
    // textures
    texStrategy: 'perMotif',
    texId: 'roughConcrete',
    texPool: [...TEXTURE_PRESETS],
    // attempts
    tries: 10,
  };

  constructor(opts = {}) {
    this.o = { ...RVGG.DEFAULTS, ...opts };
    this._gid = 0;
  }

  /* ---------- Utils ---------- */
  _makeRng(seed = 0x9e3779b1) {
    let s = (seed >>> 0) || 0x9e3779b1;
    return () => {
      s ^= s << 13;
      s ^= s >>> 17;
      s ^= s << 5;
      return ((s >>> 0) / 0xFFFFFFFF);
    };
  }

  _chance(r, p) { return r() < p; }
  _pick(r, arr) { return arr[Math.floor(r() * arr.length)]; }
  _range(r, a, b) { return a + (b - a) * r(); }
  _irange(r, a, b) { return Math.floor(this._range(r, a, b + 1)); }
  
  _fmt(n) {
    const s = Number(n).toFixed(5);
    if (s.endsWith(".00000")) return String(Math.round(Number(n)));
    return s.replace(/0+$/, "").replace(/\.$/, ".0");
  }

  _pickTex(r) {
    const pool = (Array.isArray(this.o.texPool) && this.o.texPool.length)
      ? this.o.texPool : TEXTURE_PRESETS;
    return this._pick(r, pool);
  }

  _u() {
    this._gid += 1;
    return this._gid;
  }

  _pickFrom(list) {
    return list[Math.floor(Math.random() * list.length)];
  }

  _dsForAxis(axis, xExpr) {
    if (axis === 0) return `DS ( ${xExpr} 1 1 )`;
    if (axis === 1) return `DS ( 1 ${xExpr} 1 )`;
    return `DS ( 1 1 ${xExpr} )`;
  }

  _elementRule(u, tex, prim, scale, axisExpr, xExpr) {
    const a1 = `${this._pickFrom([90, 180, 270])} ${this._pickFrom([0, 1, 2])}`;
    const a2 = `${this._pickFrom([90, 180, 270])} ${this._pickFrom([0, 1, 2])}`;
    const ds = this._dsForAxis(axisExpr, xExpr);
    return `Element${u} 1 -> [
  ${ds}
  A ( ${a1} )
  A ( ${a2} )
  I ( ${prim} ${tex} ${scale} )
]`;
  }

  /* ---------- Motifs ---------- */
  _motifSpokes(rng, tex) {
    const u = this._u();
    const prim = "Cube";
    const R = this._fmt(this._range(rng, 1.2, 3.2));
    const s = this._fmt(this._range(rng, this.o.scaleMin, this.o.scaleMax));
    const axis = 1;
    const xExpr = `k${u}/N${u}`;
    const element = this._elementRule(u, tex, prim, s, axis, xExpr);

    return {
      rules: [
        `Spokes${u} -> R* N${u} ( ${this.o.spokesMin} ${this.o.spokesMax} ) Spokes${u}Init

Spokes${u}Init 1 N${u} -> R* k${u} ( 0 N${u}/2 ) Spokes${u}Core

Spokes${u}Core 1 N${u} k${u} -> 
  A ( 360/N${u}*k${u} ${axis} )
  [ T ( ${R} 0 0 ) Element${u} ]

${element}`
      ],
      main: [`Spokes${u}`]
    };
  }

  _motifDihedral(rng, tex) {
    const u = this._u();
    const prim = "Cube";
    const R = this._fmt(this._range(rng, 1.2, 3.2));
    const s = this._fmt(this._range(rng, this.o.scaleMin, this.o.scaleMax));
    const axis = 1;
    const xExpr = `k${u}/N${u}`;
    const element = this._elementRule(u, tex, prim, s, axis, xExpr);

    return {
      rules: [
        `Dihedral${u} -> R* N${u} ( ${this.o.spokesMin} ${this.o.spokesMax} ) Dihedral${u}Init

Dihedral${u}Init 1 N${u} -> R* k${u} ( 0 N${u}/2 ) Dihedral${u}Core

Dihedral${u}Core 1 N${u} k${u} ->
  A ( 360/N${u}*k${u} ${axis} )
  [ T ( ${R} 0 0 ) Element${u} ]
  A ( 360/N${u}*k${u} ${axis} )
  [ A ( 180 2 ) T ( ${R} 0 0 ) Element${u} ]

${element}`
      ],
      main: [`Dihedral${u}`]
    };
  }

  _motifStack(rng, tex) {
    const u = this._u();
    const prim = "Cube";
    const h = this._fmt(this._range(rng, .35, 1.8));
    const s = this._fmt(this._range(rng, this.o.scaleMin, this.o.scaleMax));
    const axis = 1;
    const xExpr = `i${u}/H${u}`;

    return {
      rules: [
        `Stack${u} -> R* H${u} ( ${this.o.stacksMin} ${this.o.stacksMax} ) Stack${u}Init

Stack${u}Init 1 H${u} -> R* i${u} ( 0 H${u}/2 ) Stack${u}Core

Stack${u}Core 1 H${u} i${u} ->
  A ( 0 1 ) 
  [ T ( 0 ${h}*i${u} 0 ) Element${u} ]

Element${u} 1 -> [
  ${this._dsForAxis(axis, xExpr)}
  A ( 90 0 )
  A ( 180 2 )
  I ( ${prim} ${tex} ${s} )
]`
      ],
      main: [`Stack${u}`]
    };
  }

  _motifBand(rng, tex) {
    const u = this._u();
    const prim = "CubeX";
    const L = this._fmt(this._range(rng, 2, 8));
    const mod = this._fmt(this._range(rng, .7, 1.3));
    const s2 = this._fmt(this._range(rng, this.o.scaleMin, this.o.scaleMax));
    const axis = 0;
    const xExpr = `k${u}/N${u}`;
    const element = this._elementRule(u, tex, prim, s2, axis, xExpr);

    return {
      rules: [
        `Band${u} -> R* N${u} ( ${this.o.bandSegMin} ${this.o.bandSegMax} ) Band${u}Init

Band${u}Init 1 N${u} -> R* k${u} ( 0 N${u}/2 ) Band${u}Core

Band${u}Core 1 N${u} k${u} ->
  A ( 0 0 )
  [ T ( ${L}*(k${u}/(N${u}-1)) 0 0 ) S ( 1 ${mod} 1 ) Element${u} ]

${element}`
      ],
      main: [`Band${u}`]
    };
  }

  _motifMirror(rng, tex) {
    const u = this._u();
    const prim = this._pick(rng, ["Cube", "CubeX", "CubeY"]);
    const dx = this._fmt(this._range(rng, .6, 2.4));
    const s = this._fmt(this._range(rng, this.o.scaleMin, this.o.scaleMax));
    const axis = 0;
    const xExpr = `k${u}/M${u}`;
    const element = this._elementRule(u, tex, prim, s, axis, xExpr);

    return {
      rules: [
        `Mirror${u} -> R* M${u} ( 2 2 ) Mirror${u}Init

Mirror${u}Init 1 M${u} -> R* k${u} ( 0 M${u}/2 ) Mirror${u}Core

Mirror${u}Core 1 M${u} k${u} ->
  A ( 0 1 )
  [ T ( ${dx} 0 0 ) Element${u} ]
  [ T ( -${dx} 0 0 ) Element${u} ]

${element}`
      ],
      main: [`Mirror${u}`]
    };
  }

  _motifSpiral(rng, tex) {
    const u = this._u();
    const prim = "CubeY";
    const radius = this._fmt(this._range(rng, 1, 3));
    const rise = this._fmt(this._range(rng, .2, 1));
    const s = this._fmt(this._range(rng, .2, .8));
    const axis = 1;
    const xExpr = `k${u}/N${u}`;
    const element = this._elementRule(u, tex, prim, s, axis, xExpr);

    return {
      rules: [
        `Spiral${u} -> R* N${u} ( ${this.o.spiralSegMin} ${this.o.spiralSegMax} ) Spiral${u}Init

Spiral${u}Init 1 N${u} -> R* k${u} ( 0 N${u}/2 ) Spiral${u}Core

Spiral${u}Core 1 N${u} k${u} ->
  A ( 360/N${u}*k${u} ${axis} )
  [ T ( ${radius} 0 0 ) T ( 0 ${rise}*k${u} 0 ) Element${u} ]

${element}`
      ],
      main: [`Spiral${u}`]
    };
  }

  _motifGrid(rng, tex) {
    const u = this._u();
    const prim = "Cube";
    const pitch = this._fmt(this._range(rng, .8, 2.5));
    const s = this._fmt(this._range(rng, .2, .8));
    const axis = 2;
    const xExpr = `(ix${u}+iz${u})/(NX${u}+NZ${u})`;

    return {
      rules: [
        `Grid${u} -> R* NX${u} ( ${this.o.gridNMin} ${this.o.gridNMax} ) R* NZ${u} ( ${this.o.gridNMin} ${this.o.gridNMax} ) Grid${u}Init

Grid${u}Init 1 NX${u} NZ${u} -> R* ix${u} ( 0 NX${u}/2 ) R* iz${u} ( 0 NZ${u}/2 ) Grid${u}Core

Grid${u}Core 1 NX${u} NZ${u} ix${u} iz${u} ->
  A ( 0 0 )
  [ T ( ${pitch}*ix${u} 0 ${pitch}*iz${u} ) Element${u} ]

Element${u} 1 -> [
  ${this._dsForAxis(axis, xExpr)}
  A ( 90 1 )
  A ( 270 0 )
  I ( ${prim} ${tex} ${s} )
]`
      ],
      main: [`Grid${u}`]
    };
  }

  _motifRandomWalk(rng, tex) {
    const u = this._u();
    const prim = "Cube";
    const stepLen = this._fmt(this._range(rng, .5, 2));
    const s = this._fmt(this._range(rng, .18, .7));
    const axis = this._irange(rng, 0, 2);
    const aStep = this._fmt(this._range(rng, -45, 45));
    const xExpr = `i${u}/S${u}`;
    const element = this._elementRule(u, tex, prim, s, axis, xExpr);

    return {
      rules: [
        `Walk${u} -> R* S${u} ( 6 16 ) Walk${u}Init

Walk${u}Init 1 S${u} -> R* i${u} ( 0 S${u}/2 ) Walk${u}Core

Walk${u}Core 1 S${u} i${u} ->
  A ( ${aStep} ${axis} )
  [ T ( ${stepLen} 0 0 ) Element${u} ]

${element}`
      ],
      main: [`Walk${u}`]
    };
  }

  _motifFork(rng, tex) {
    const u = this._u();
    const prim = "Cube";
    const ang = this._fmt(this._range(rng, 15, 45));
    const len = this._fmt(this._range(rng, .6, 1.8));
    const s = this._fmt(this._range(rng, .15, .6));
    const axis = 2;
    const xExpr = `d${u}/D${u}`;
    const element = this._elementRule(u, tex, prim, s, axis, xExpr);

    return {
      rules: [
        `Fork${u} -> R* D${u} ( ${this.o.forkDepthMin} ${this.o.forkDepthMax} ) Fork${u}Init

Fork${u}Init 1 D${u} -> R* d${u} ( 0 D${u}/2 ) Fork${u}Core

Fork${u}Core 1 D${u} d${u} ->
  A ( 0 2 )
  [ T ( ${len}*d${u} 0 0 ) Element${u} ]
  [ T ( ${len}*d${u} 0 0 ) A ( ${ang} 2 ) Element${u} ]
  [ T ( ${len}*d${u} 0 0 ) A ( -${ang} 2 ) Element${u} ]

${element}`
      ],
      main: [`Fork${u}`]
    };
  }

  _motifRingStack(rng, tex) {
    const u = this._u();
    const prim = "Cube";
    const rad = this._fmt(this._range(rng, 1.2, 3.5));
    const s = this._fmt(this._range(rng, .18, .6));
    const height = this._fmt(this._range(rng, .4, 1.4));
    const axis = 1;
    const xExpr = `k${u}/N${u}`;
    const element = this._elementRule(u, tex, prim, s, axis, xExpr);

    return {
      rules: [
        `Ring${u} -> R* N${u} ( ${this.o.ringNMin} ${this.o.ringNMax} ) Ring${u}Init

Ring${u}Init 1 N${u} -> R* k${u} ( 0 N${u}/2 ) Ring${u}Core

Ring${u}Core 1 N${u} k${u} ->
  A ( 360/N${u}*k${u} ${axis} )
  [ T ( ${rad} 0 0 ) Element${u} ]

Rings${u} -> R* L${u} ( ${this.o.ringLayersMin} ${this.o.ringLayersMax} ) Rings${u}Init

Rings${u}Init 1 L${u} -> R* i${u} ( 0 L${u}/2 ) Rings${u}Core

Rings${u}Core 1 L${u} i${u} ->
  A ( 0 1 )
  [ T ( 0 ${height}*i${u} 0 ) Ring${u} ]

${element}`
      ],
      main: [`Rings${u}`]
    };
  }

  /* ---------- NEW: L-System Integration ---------- */
  _motifLSystem(rng, tex) {
    const u = this._u();
    const templates = [
      GrammarLibrary.TREE_SIMPLE,
      GrammarLibrary.BUSH,
      GrammarLibrary.STOCHASTIC_TREE
    ];
    
    const template = this._pick(rng, templates);
    const lsys = new ProGen3DGrammar({
      ...template, seed: Math.floor(rng() * 1000000)
    });
    
    const lstring = lsys.generate();
    const commands = lsys.interpret(lstring);
    
    // Convert L-System commands to RVGG grammar rules
    const prim = "Cube";
    const s = this._fmt(this._range(rng, .15, .5));
    const scale = this._fmt(this._range(rng, .8, 1.2));
    
    // Generate RVGG rules from L-System interpretation
    const rules = [];
    let segmentCount = 0;
    
    for (let i = 0; i < commands.length; i++) {
      const cmd = commands[i];
      if (cmd.type === 'line') {
        segmentCount++;
      }
    }
    
    const axis = 1;
    const xExpr = `seg${u}/SEG${u}`;
    
    rules.push(`LSystem${u} -> R* SEG${u} ( ${Math.max(1, segmentCount)} ${Math.max(1, segmentCount)} ) LSystem${u}Init

LSystem${u}Init 1 SEG${u} -> R* seg${u} ( 0 SEG${u}/2 ) LSystem${u}Core

LSystem${u}Core 1 SEG${u} seg${u} -> [
  S ( ${scale} ${scale} ${scale} )
  LSystem${u}Branch
]

LSystem${u}Branch 1 -> [
  ${this._dsForAxis(axis, xExpr)}
  A ( ${this._fmt(this._range(rng, 0, 360))} ${axis} )
  I ( ${prim} ${tex} ${s} )
]`);

    return {
      rules,
      main: [`LSystem${u}`],
      metadata: {
        type: 'lsystem',
        axiom: template.axiom,
        iterations: template.iterations,
        segments: segmentCount
      }
    };
  }

  /* ---------- Motif Registry ---------- */
  _allMotifs() {
    return [
      { p: "pRadial", fn: (r, t) => this._motifSpokes(r, t) },
      { p: "pDihedral", fn: (r, t) => this._motifDihedral(r, t) },
      { p: "pStack", fn: (r, t) => this._motifStack(r, t) },
      { p: "pBand", fn: (r, t) => this._motifBand(r, t) },
      { p: "pMirror", fn: (r, t) => this._motifMirror(r, t) },
      { p: "pSpiral", fn: (r, t) => this._motifSpiral(r, t) },
      { p: "pGrid", fn: (r, t) => this._motifGrid(r, t) },
      { p: "pRandomWalk", fn: (r, t) => this._motifRandomWalk(r, t) },
      { p: "pFork", fn: (r, t) => this._motifFork(r, t) },
      { p: "pRingStack", fn: (r, t) => this._motifRingStack(r, t) },
      { p: "pLSystem", fn: (r, t) => this._motifLSystem(r, t) }, // NEW
    ];
  }

  /* ---------- Program Generation ---------- */
  generateGrammar(seed = Date.now()) {
    const o = this.o, rng = this._makeRng(seed);
    const chosen = [], rules = [], main = [], usedTex = new Set();
    const metadata = { motifs: [], lsystems: [] };
    const globalTex = (o.texStrategy === 'global') ? (o.texId || this._pickTex(rng)) : null;

    for (const M of this._allMotifs()) {
      if (this._chance(rng, o[M.p])) {
        const tex = globalTex || this._pickTex(rng);
        usedTex.add(tex);
        const r = M.fn(rng, tex);
        rules.push(...r.rules);
        main.push(...r.main);
        chosen.push(`${r.main.join(",")}:${tex}`);
        
        // Track L-System metadata
        if (r.metadata && r.metadata.type === 'lsystem') {
          metadata.lsystems.push(r.metadata);
        }
      }
    }

    // Ensure at least one motif
    if (main.length === 0) {
      const L = this._allMotifs();
      const M = L[Math.floor(rng() * L.length)];
      const tex = globalTex || this._pickTex(rng);
      usedTex.add(tex);
      const r = M.fn(rng, tex);
      rules.push(...r.rules);
      main.push(...r.main);
      chosen.push(`${r.main.join(",")}:${tex}`);
    }

    const pre = `S ( ${this._fmt(this._range(rng, .9, 1.2))} ${this._fmt(this._range(rng, .9, 1.2))} ${this._fmt(this._range(rng, .9, 1.2))} )`;
    const post = `T ( ${this._fmt(this._range(rng, -.8, .8))} ${this._fmt(this._range(rng, -.4, .4))} ${this._fmt(this._range(rng, -.8, .8))} )`;
    const start = `Start 1 -> ${pre} | ${main.join(" ")} | ${post}`;

    const program = [start, ...rules].join("\n\n");
    
    metadata.motifs = chosen;
    
    return {
      seed,
      program,
      manifest: {
        motifs: chosen,
        textures: [...usedTex],
        strategy: o.texStrategy,
        lsystems: metadata.lsystems
      }
    };
  }

  /* ---------- Fitness Evaluation ---------- */
  computeFitness(program) {
    let score = 50;
    
    // Instance count
    const inst = (program.match(/\bI\s*\(/g) || []).length;
    score += Math.min(inst * 2.5, 25);
    
    // Rule diversity (allow heads with `1`)
    const diversity = (program.match(/^[A-Za-z]\w*\s+1\s.*->/gm) || []).length;
    score += Math.min(diversity * 2, 16);
    
    // Symmetry bonus
    if (/\bSpokes|Dihedral|Ring|Rings\b/.test(program)) score += 6;
    
    // L-System bonus
    if (/\bLSystem\d+\b/.test(program)) score += 8;
    
    // Scale validation
    if (/\bS\s*\([^)]+\)/.test(program)) {
      const m = program.match(/\bS\s*\(([^)]+)\)/g) || [];
      for (const s of m) {
        const nums = (s.match(/-?\d+(?:\.\d+)?/g) || []).map(Number);
        for (const v of nums) {
          if (v <= .05 || v > 6) score -= 6;
        }
      }
    }
    
    // Translation validation
    if (/\bT\s*\(([^)]+)\)/.test(program)) {
      const m = program.match(/\bT\s*\(([^)]+)\)/g) || [];
      for (const t of m) {
        const nums = (t.match(/-?\d+(?:\.\d+)?/g) || []).map(Number);
        for (const v of nums) {
          if (Math.abs(v) > 12) score -= 4;
        }
      }
    }
    
    // Start rule validation
    if (!/^\s*Start\b.*->/m.test(program)) score -= 30;
    
    // Pipe separator validation
    if ((program.match(/\|/g) || []).length < 1) score -= 6;
    
    // Complexity bonus
    const lines = program.split('\n').length;
    if (lines > 50) score += 5;
    if (lines > 100) score += 5;
    
    return Math.max(0, score);
  }

  /* ---------- Selection & Generation ---------- */
  generateValid(seed = Date.now()) {
    const tries = this.o.tries | 0 || 1;
    let best = null;
    
    for (let k = 0; k < tries; k++) {
      const g = this.generateGrammar((seed != null) ? (seed + k) : (Date.now() + k));
      const score = this.computeFitness(g.program);
      if (!best || score > best.score) {
        best = { ...g, score };
      }
    }
    
    return best;
  }

  /* ---------- UI Integration ---------- */
  attachRandomizeButton(button, onProgram) {
    if (!button || typeof onProgram !== "function") return;
    button.addEventListener("click", () => {
      const out = this.generateValid(Date.now());
      onProgram(out.program, {
        seed: out.seed,
        manifest: out.manifest,
        score: out.score
      });
    });
  }
}

/* ================= SHAPE GRAMMAR GENERATOR ================= */
class ShapeGrammar {
  constructor() {
    this.shapes = [];
    this.rules = [];
    this.seed = Date.now();
    this.rng = this._makeRng(this.seed);
  }

  _makeRng(seed = 0x9e3779b1) {
    let s = (seed >>> 0) || 0x9e3779b1;
    return () => {
      s ^= s << 13;
      s ^= s >>> 17;
      s ^= s << 5;
      return ((s >>> 0) / 0xFFFFFFFF);
    };
  }

  addShape(shape) {
    this.shapes.push(shape);
    return this;
  }

  addRule(pattern, replacement) {
    this.rules.push({ pattern, replacement });
    return this;
  }

  generate(iterations = 1) {
    let currentShapes = [...this.shapes];

    for (let i = 0; i < iterations; i++) {
      const newShapes = [];

      for (const shape of currentShapes) {
        let replaced = false;

        for (const rule of this.rules) {
          if (this.matchPattern(shape, rule.pattern)) {
            newShapes.push(...this.applyReplacement(shape, rule.replacement));
            replaced = true;
            break;
          }
        }

        if (!replaced) {
          newShapes.push(shape);
        }
      }

      currentShapes = newShapes;
    }

    return currentShapes;
  }

  matchPattern(shape, pattern) {
    if (typeof pattern === 'function') {
      return pattern(shape);
    }
    return shape.type === pattern.type;
  }

  applyReplacement(shape, replacement) {
    if (typeof replacement === 'function') {
      return replacement(shape);
    }
    return [replacement];
  }

  /* ---------- Convert to RVGG Format ---------- */
  toRVGG(textures = TEXTURE_PRESETS) {
    const rules = [];
    const main = [];
    let gid = 0;

    for (const shape of this.shapes) {
      const u = ++gid;
      const tex = textures[Math.floor(this.rng() * textures.length)];
      const scale = (0.5 + this.rng() * 1.5).toFixed(3);
      
      const rule = `Shape${u} 1 -> [
  S ( ${shape.width || 1} ${shape.height || 1} ${shape.depth || 1} )
  T ( ${shape.x || 0} ${shape.y || 0} ${shape.z || 0} )
  I ( Cube ${tex} ${scale} )
]`;
      
      rules.push(rule);
      main.push(`Shape${u}`);
    }

    const start = `Start 1 -> ${main.join(" ")}`;
    return [start, ...rules].join("\n\n");
  }

  /* ---------- Building Generator ---------- */
  static createBuildingGrammar(seed = Date.now()) {
    const grammar = new ShapeGrammar();
    grammar.seed = seed;
    grammar.rng = grammar._makeRng(seed);

    // Initial ground floor
    grammar.addShape({
      type: 'floor',
      level: 0,
      width: 20,
      depth: 20,
      height: 4,
      x: 0,
      y: 0,
      z: 0
    });

    // Rule: Add floors
    grammar.addRule(
      shape => shape.type === 'floor' && shape.level < 10,
      shape => [
        shape,
        {
          type: 'floor',
          level: shape.level + 1,
          width: shape.width * 0.95,
          depth: shape.depth * 0.95,
          height: 3,
          x: 0,
          y: shape.y + shape.height,
          z: 0
        }
      ]
    );

    // Rule: Add windows
    grammar.addRule(
      shape => shape.type === 'floor',
      shape => [
        shape,
        {
          type: 'windows',
          level: shape.level,
          count: Math.floor(shape.width / 2),
          x: shape.x,
          y: shape.y,
          z: shape.z
        }
      ]
    );

    return grammar;
  }

  /* ---------- City Generator ---------- */
  static createCityGrammar(seed = Date.now()) {
    const grammar = new ShapeGrammar();
    grammar.seed = seed;
    grammar.rng = grammar._makeRng(seed);

    // City blocks
    const gridSize = 5;
    const blockSize = 30;

    for (let i = 0; i < gridSize; i++) {
      for (let j = 0; j < gridSize; j++) {
        if (grammar.rng() > 0.3) { // 70% chance of building
          grammar.addShape({
            type: 'building',
            x: i * blockSize,
            y: 0,
            z: j * blockSize,
            width: blockSize * 0.8,
            depth: blockSize * 0.8,
            height: 5 + grammar.rng() * 20
          });
        }
      }
    }

    return grammar;
  }
}

/* ================= GRAMMAR ANALYZER ================= */
class GrammarAnalyzer {
  static analyzeComplexity(grammar) {
    const generated = grammar.generate();
    
    return {
      length: generated.length,
      uniqueSymbols: new Set(generated).size,
      depth: grammar.iterations,
      branchingFactor: this.calculateBranchingFactor(grammar),
      growthRate: generated.length / grammar.axiom.length
    };
  }

  static calculateBranchingFactor(grammar) {
    let totalBranches = 0;
    let branchSymbols = 0;

    for (const [symbol, rule] of Object.entries(grammar.rules)) {
      if (typeof rule === 'string') {
        const branches = (rule.match(/\[/g) || []).length;
        if (branches > 0) {
          totalBranches += branches;
          branchSymbols++;
        }
      }
    }

    return branchSymbols > 0 ? totalBranches / branchSymbols : 0;
  }

  static detectInfiniteLoops(grammar) {
    function checkSymbol(symbol, path = []) {
      if (path.includes(symbol)) {
        return true; // Cycle detected
      }

      const rule = grammar.rules[symbol];
      if (!rule || typeof rule !== 'string') {
        return false;
      }

      for (const char of rule) {
        if (grammar.rules[char]) {
          if (checkSymbol(char, [...path, symbol])) {
            return true;
          }
        }
      }

      return false;
    }

    return checkSymbol(grammar.axiom);
  }

  static suggestOptimizations(grammar) {
    const suggestions = [];
    const complexity = this.analyzeComplexity(grammar);

    if (complexity.length > 10000) {
      suggestions.push({
        type: 'warning',
        message: 'Generated string is very long. Consider reducing iterations.',
        severity: 'high'
      });
    }

    if (complexity.branchingFactor > 5) {
      suggestions.push({
        type: 'info',
        message: 'High branching factor detected. This may cause exponential growth.',
        severity: 'medium'
      });
    }

    if (this.detectInfiniteLoops(grammar)) {
      suggestions.push({
        type: 'error',
        message: 'Potential infinite loop detected in grammar rules.',
        severity: 'critical'
      });
    }

    return suggestions;
  }

  /* ---------- RVGG Program Analysis ---------- */
  static analyzeRVGG(program) {
    const analysis = {
      ruleCount: 0,
      instanceCount: 0,
      transformCount: 0,
      motifs: [],
      textures: new Set(),
      complexity: 0
    };

    // Count rules
    analysis.ruleCount = (program.match(/^[A-Za-z]\w*\s+\d+\s*->/gm) || []).length;

    // Count instances
    analysis.instanceCount = (program.match(/\bI\s*\(/g) || []).length;

    // Count transforms
    analysis.transformCount = (program.match(/\b[TSAR]\s*\(/g) || []).length;

    // Detect motifs
    const motifPatterns = [
      { name: 'Radial', pattern: /\bSpokes\d+\b/ },
      { name: 'Dihedral', pattern: /\bDihedral\d+\b/ },
      { name: 'Stack', pattern: /\bStack\d+\b/ },
      { name: 'Band', pattern: /\bBand\d+\b/ },
      { name: 'Mirror', pattern: /\bMirror\d+\b/ },
      { name: 'Spiral', pattern: /\bSpiral\d+\b/ },
      { name: 'Grid', pattern: /\bGrid\d+\b/ },
      { name: 'Walk', pattern: /\bWalk\d+\b/ },
      { name: 'Fork', pattern: /\bFork\d+\b/ },
      { name: 'Ring', pattern: /\bRing\d+\b/ },
      { name: 'L-System', pattern: /\bLSystem\d+\b/ }
    ];

    for (const motif of motifPatterns) {
      if (motif.pattern.test(program)) {
        analysis.motifs.push(motif.name);
      }
    }

    // Extract textures
    const texMatches = program.match(/\bI\s*\(\s*\w+\s+(\w+)/g) || [];
    for (const match of texMatches) {
      const tex = match.match(/\bI\s*\(\s*\w+\s+(\w+)/)[1];
      analysis.textures.add(tex);
    }

    // Calculate complexity score
    analysis.complexity = 
      analysis.ruleCount * 2 +
      analysis.instanceCount * 1.5 +
      analysis.transformCount * 0.5 +
      analysis.motifs.length * 5;

    return analysis;
  }
}

/* ================= GRAMMAR VISUALIZER ================= */
class GrammarVisualizer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.scale = 1;
    this.offset = { x: 0, y: 0 };
    this.rotation = { x: 0, y: 0, z: 0 };
  }

  draw(commands, options = {}) {
    const {
      lineWidth = 1,
      strokeStyle = '#000000',
      fillStyle = '#00ff00',
      scale = 10,
      centerX = this.canvas.width / 2,
      centerY = this.canvas.height / 2
    } = options;

    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.lineWidth = lineWidth;
    this.ctx.strokeStyle = strokeStyle;
    this.ctx.fillStyle = fillStyle;

    let polygonVertices = [];
    let inPolygon = false;

    for (const command of commands) {
      switch (command.type) {
        case 'line':
          this.ctx.beginPath();
          this.ctx.moveTo(
            centerX + command.from.x * scale,
            centerY - command.from.y * scale
          );
          this.ctx.lineTo(
            centerX + command.to.x * scale,
            centerY - command.to.y * scale
          );
          this.ctx.stroke();
          break;

        case 'startPolygon':
          inPolygon = true;
          polygonVertices = [];
          break;

        case 'vertex':
          if (inPolygon) {
            polygonVertices.push({
              x: centerX + command.position.x * scale,
              y: centerY - command.position.y * scale
            });
          }
          break;

        case 'endPolygon':
          if (polygonVertices.length > 0) {
            this.ctx.beginPath();
            this.ctx.moveTo(polygonVertices[0].x, polygonVertices[0].y);
            for (let i = 1; i < polygonVertices.length; i++) {
              this.ctx.lineTo(polygonVertices[i].x, polygonVertices[i].y);
            }
            this.ctx.closePath();
            this.ctx.fill();
            this.ctx.stroke();
          }
          inPolygon = false;
          polygonVertices = [];
          break;
      }
    }
  }

  draw3D(commands, options = {}) {
    const {
      scale = 10,
      rotationX = 0,
      rotationY = 0,
      rotationZ = 0
    } = options;

    // Project 3D points to 2D
    const projected = commands.map(cmd => {
      if (cmd.type === 'line') {
        return {
          type: 'line',
          from: this.project3D(cmd.from, rotationX, rotationY, rotationZ),
          to: this.project3D(cmd.to, rotationX, rotationY, rotationZ)
        };
      }
      return cmd;
    });

    this.draw(projected, { ...options, scale });
  }

  project3D(point, rotX, rotY, rotZ) {
    let { x, y, z } = point;

    // Rotate around X axis
    const cosX = Math.cos(rotX);
    const sinX = Math.sin(rotX);
    let y1 = y * cosX - z * sinX;
    let z1 = y * sinX + z * cosX;

    // Rotate around Y axis
    const cosY = Math.cos(rotY);
    const sinY = Math.sin(rotY);
    let x1 = x * cosY + z1 * sinY;
    let z2 = -x * sinY + z1 * cosY;

    // Rotate around Z axis
    const cosZ = Math.cos(rotZ);
    const sinZ = Math.sin(rotZ);
    let x2 = x1 * cosZ - y1 * sinZ;
    let y2 = x1 * sinZ + y1 * cosZ;

    // Perspective projection
    const distance = 5;
    const factor = distance / (distance + z2);

    return {
      x: x2 * factor,
      y: y2 * factor,
      z: z2
    };
  }

  clear() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }

  setRotation(x, y, z) {
    this.rotation = { x, y, z };
  }

  animate(commands, options = {}) {
    const { duration = 5000, fps = 60 } = options;
    const frames = (duration / 1000) * fps;
    let frame = 0;

    const animationLoop = () => {
      if (frame >= frames) return;

      const progress = frame / frames;
      const rotY = progress * Math.PI * 2;

      this.draw3D(commands, {
        ...options,
        rotationY: rotY
      });

      frame++;
      requestAnimationFrame(animationLoop);
    };

    animationLoop();
  }
}

/* ================= UNIFIED GRAMMAR SYSTEM ================= */
class ProGen3DUnifiedGrammar {
  constructor(options = {}) {
    this.rvgg = new RVGG(options.rvgg || {});
    this.lsystem = null;
    this.shapeGrammar = null;
    this.mode = options.mode || 'rvgg'; // 'rvgg', 'lsystem', 'shape', 'hybrid'
  }

  /* ---------- Generate based on mode ---------- */
  generate(seed = Date.now()) {
    switch (this.mode) {
      case 'rvgg':
        return this.rvgg.generateValid(seed);

      case 'lsystem':
        return this.generateLSystem(seed);

      case 'shape':
        return this.generateShapeGrammar(seed);

      case 'hybrid':
        return this.generateHybrid(seed);

      default:
        return this.rvgg.generateValid(seed);
    }
  }

  generateLSystem(seed) {
    const templates = [
      GrammarLibrary.TREE_SIMPLE,
      GrammarLibrary.TREE_COMPLEX,
      GrammarLibrary.BUSH,
      GrammarLibrary.PLANT_3D,
      GrammarLibrary.STOCHASTIC_TREE
    ];

    const template = templates[Math.floor(Math.random() * templates.length)];
    this.lsystem = new ProGen3DGrammar({ ...template, seed });
    
    const lstring = this.lsystem.generate();
    const commands = this.lsystem.interpret(lstring);

    return {
      seed,
      program: lstring,
      commands,
      manifest: {
        type: 'lsystem',
        template: template.axiom,
        length: lstring.length,
        commandCount: commands.length
      }
    };
  }

  generateShapeGrammar(seed) {
    this.shapeGrammar = ShapeGrammar.createBuildingGrammar(seed);
    const shapes = this.shapeGrammar.generate(10);
    const program = this.shapeGrammar.toRVGG();

    return {
      seed,
      program,
      shapes,
      manifest: {
        type: 'shape',
        shapeCount: shapes.length
      }
    };
  }

  generateHybrid(seed) {
    // Combine RVGG with L-System elements
    const rvggResult = this.rvgg.generateValid(seed);
    const lsystemResult = this.generateLSystem(seed + 1);

    // Merge programs
    const hybridProgram = `${rvggResult.program}\n\n// L-System Integration\n${lsystemResult.program}`;

    return {
      seed,
      program: hybridProgram,
      manifest: {
        type: 'hybrid',
        rvgg: rvggResult.manifest,
        lsystem: lsystemResult.manifest
      },
      score: rvggResult.score
    };
  }

  /* ---------- Analysis ---------- */
  analyze(program) {
    return GrammarAnalyzer.analyzeRVGG(program);
  }

  /* ---------- Visualization ---------- */
  visualize(canvas, program, options = {}) {
    const visualizer = new GrammarVisualizer(canvas);
    
    if (this.mode === 'lsystem' && this.lsystem) {
      const commands = this.lsystem.interpret(program);
      visualizer.draw3D(commands, options);
    } else {
      // For RVGG, would need additional parsing
      console.log('RVGG visualization requires 3D engine integration');
    }

    return visualizer;
  }
}

/* ================= EXPORT ================= */
if (typeof window !== 'undefined') {
  window.ProGen3DGrammar = ProGen3DGrammar;
  window.GrammarLibrary = GrammarLibrary;
  window.RVGG = RVGG;
  window.ShapeGrammar = ShapeGrammar;
  window.GrammarAnalyzer = GrammarAnalyzer;
  window.GrammarVisualizer = GrammarVisualizer;
  window.ProGen3DUnifiedGrammar = ProGen3DUnifiedGrammar;
  window.TEXTURE_PRESETS = TEXTURE_PRESETS;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    ProGen3DGrammar,
    GrammarLibrary,
    RVGG,
    ShapeGrammar,
    GrammarAnalyzer,
    GrammarVisualizer,
    ProGen3DUnifiedGrammar,
    TEXTURE_PRESETS
  };
}
